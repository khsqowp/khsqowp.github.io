# Chapter 2: 아마존 웹 서비스 사용 시작하기 (상세판)

> **학습 목표**: AWS 계정 생성부터 서비스 접근 방법, 비용 관리, 인프라 위치 선택까지 AWS를 실제로 사용하기 위한 모든 기본 지식을 습득한다.

---

## 📌 목차

1. [AWS 계정 생성과 로그인](#1-aws-계정-생성과-로그인)
2. [AWS 서비스 접근 방법](#2-aws-서비스-접근-방법)
3. [AWS 비용 관리 도구](#3-aws-비용-관리-도구)
4. [AWS 시스템 구축 위치 선택](#4-aws-시스템-구축-위치-선택)
5. [요약](#5-요약)

---

## 1. AWS 계정 생성과 로그인

### 1.1 AWS 계정 생성 절차

#### 계정 생성 준비물

**필수 항목**:
1. **이메일 주소**
   - 고유한 이메일 (다른 AWS 계정에 사용되지 않은 것)
   - 접근 가능한 이메일 (인증 메일 수신)
   - 권장: 업무용 이메일

2. **결제 정보**
   - 신용카드 또는 체크카드
   - 카드 인증을 위해 $1 임시 결제 (즉시 환불)
   - 지원 카드: Visa, MasterCard, American Express

3. **전화번호**
   - SMS 또는 음성 통화로 인증
   - 국제 전화번호 형식

4. **신분증**
   - 일부 국가에서 요구
   - 계정 보안 강화용

#### 계정 생성 단계

**1단계: 기본 정보 입력**
```
- 이메일 주소
- 비밀번호 (최소 8자, 대소문자, 숫자, 특수문자 포함 권장)
- AWS 계정 이름 (회사명 또는 프로젝트명)
```

**2단계: 연락처 정보**
```
- 계정 유형 선택:
  • Personal (개인): 개인 학습, 취미 프로젝트
  • Professional (비즈니스): 회사, 조직

- 전체 이름
- 전화번호
- 국가/지역
- 주소
```

**3단계: 결제 정보**
```
- 신용카드 정보 입력
- 청구 주소
- $1 임시 결제 승인 (즉시 환불)
```

**4단계: 자격 증명 확인**
```
- 전화번호 인증
- SMS 또는 음성 통화 선택
- 4자리 인증 코드 입력
```

**5단계: 지원 플랜 선택**
```
- Basic (무료) - 권장
- Developer ($29/월)
- Business ($100/월)
- Enterprise ($15,000/월)

초기에는 Basic 선택 후 필요시 변경 가능
```

**6단계: 계정 활성화 대기**
```
- 이메일 인증
- 계정 활성화 (수 분 ~ 24시간)
- 활성화 완료 이메일 수신
```

### 1.2 루트 사용자 로그인

#### 루트 사용자란?

**정의**: AWS 계정 생성 시 자동으로 만들어지는 최고 권한 사용자

**로그인 정보**:
- **이메일 주소**: 계정 생성 시 사용한 이메일
- **비밀번호**: 계정 생성 시 설정한 비밀번호

**로그인 URL**:
```
https://console.aws.amazon.com
또는
https://signin.aws.amazon.com
```

#### 루트 사용자의 권한

**전체 권한**:
1. **모든 AWS 서비스 접근**
   - EC2, S3, RDS 등 모든 서비스
   - 모든 리소스 생성/수정/삭제

2. **계정 설정 변경**
   - 계정 이름 변경
   - 이메일 주소 변경
   - 루트 사용자 비밀번호 변경

3. **결제 정보 관리**
   - 결제 수단 추가/변경/삭제
   - 청구서 확인
   - 세금 설정

4. **지원 플랜 변경**
   - Basic ↔ Developer ↔ Business ↔ Enterprise

5. **계정 해지**
   - AWS 계정 완전 삭제
   - 모든 리소스 삭제

6. **IAM 사용자 권한 복원**
   - 모든 IAM 사용자가 권한을 잃었을 때
   - 긴급 복구 용도

#### 루트 사용자 보안 강화

**1. MFA (Multi-Factor Authentication) 설정**

**MFA란?**:
- 2단계 인증
- 비밀번호 + 추가 인증 요소

**MFA 유형**:

**가상 MFA 디바이스** (권장):
- Google Authenticator
- Microsoft Authenticator
- Authy
- 1Password

설정 방법:
```
1. AWS Console 로그인
2. 우측 상단 계정 이름 클릭
3. "Security credentials" 선택
4. "Multi-factor authentication (MFA)" 섹션
5. "Activate MFA" 클릭
6. "Virtual MFA device" 선택
7. QR 코드를 앱으로 스캔
8. 연속된 2개의 MFA 코드 입력
9. 완료
```

**하드웨어 MFA**:
- YubiKey
- Gemalto 토큰
- 물리적 디바이스

**SMS MFA** (비권장):
- 보안 취약
- 긴급 상황용

**2. 강력한 비밀번호 설정**

**권장 사항**:
```
- 최소 16자 이상
- 대문자, 소문자, 숫자, 특수문자 모두 포함
- 다른 서비스와 다른 비밀번호
- 비밀번호 관리자 사용 (1Password, LastPass 등)
```

**나쁜 예**:
```
password123
aws2024
myname@aws
```

**좋은 예**:
```
Aw$-R00t-Us3r!2024#Secure
MyC0mpany@AWS#2024!Root
```

**3. Access Key 생성 금지**

**이유**:
- 루트 사용자 Access Key는 모든 권한 보유
- 유출 시 계정 완전 탈취 가능
- 복구 어려움

**대신**:
- IAM 사용자 생성
- IAM 사용자에게 Access Key 발급

**4. 일상 작업에 사용 금지**

**루트 사용자 사용 시기**:
- ✅ 초기 IAM 사용자 생성
- ✅ 계정 설정 변경
- ✅ 결제 정보 관리
- ✅ 지원 플랜 변경
- ✅ 계정 해지

**루트 사용자 사용 금지 시기**:
- ❌ EC2 인스턴스 생성
- ❌ S3 버킷 생성
- ❌ 일상적인 개발 작업
- ❌ 애플리케이션 배포

### 1.3 IAM 사용자 로그인

#### IAM 사용자 생성 (루트 사용자가 수행)

**1단계: IAM 콘솔 접근**
```
1. 루트 사용자로 로그인
2. 서비스 검색에서 "IAM" 입력
3. IAM 대시보드 접속
```

**2단계: 사용자 생성**
```
1. 좌측 메뉴에서 "Users" 클릭
2. "Add users" 버튼 클릭
3. 사용자 이름 입력 (예: admin-user, developer-john)
4. 액세스 유형 선택:
   ☑ AWS Management Console access (콘솔 접근)
   ☑ Programmatic access (CLI/SDK 접근)
```

**3단계: 권한 설정**
```
옵션 1: 그룹에 추가
- 기존 그룹 선택 또는 새 그룹 생성
- 예: Administrators, Developers, ReadOnly

옵션 2: 기존 사용자 권한 복사
- 다른 사용자와 동일한 권한 부여

옵션 3: 정책 직접 연결
- AWS 관리형 정책 선택
- 예: AdministratorAccess, PowerUserAccess
```

**4단계: 태그 추가 (선택사항)**
```
- Department: Engineering
- Project: WebApp
- Environment: Production
```

**5단계: 검토 및 생성**
```
- 설정 내용 확인
- "Create user" 클릭
- 자격 증명 정보 다운로드 (CSV 파일)
  • 사용자 이름
  • 콘솔 로그인 URL
  • 비밀번호
  • Access Key ID
  • Secret Access Key
```

#### IAM 사용자 로그인 방법

**로그인 정보**:
1. **계정 ID** (12자리 숫자)
   - 예: 123456789012
   - 또는 계정 별칭 (예: mycompany)

2. **IAM 사용자 이름**
   - 예: admin-user

3. **비밀번호**
   - IAM 사용자 생성 시 설정

**로그인 URL**:
```
형식 1 (계정 ID):
https://123456789012.signin.aws.amazon.com/console

형식 2 (계정 별칭):
https://mycompany.signin.aws.amazon.com/console

형식 3 (일반):
https://console.aws.amazon.com
→ "IAM user" 선택
→ 계정 ID 또는 별칭 입력
```

**계정 별칭 설정**:
```
1. IAM 대시보드
2. "AWS Account" 섹션
3. "Create" 또는 "Edit" 클릭
4. 별칭 입력 (예: mycompany)
5. 저장
```

#### 루트 사용자 vs IAM 사용자 비교

| 구분 | 루트 사용자 | IAM 사용자 |
|------|-----------|-----------|
| **생성** | 계정 생성 시 자동 | 루트 사용자가 생성 |
| **로그인 ID** | 이메일 주소 | 계정 ID + 사용자 이름 |
| **권한** | 모든 권한 (변경 불가) | 부여된 권한만 |
| **MFA** | 필수 권장 | 권장 |
| **Access Key** | 생성 금지 | 필요시 생성 |
| **용도** | 초기 설정, 계정 관리 | 일상 작업 |
| **개수** | 계정당 1개 | 무제한 |

---

## 2. AWS 서비스 접근 방법

AWS 서비스에 접근하는 방법은 크게 3가지입니다.

### 2.1 AWS Management Console (관리 콘솔)

#### 개요

**정의**: 웹 브라우저를 통한 그래픽 사용자 인터페이스 (GUI)

**URL**: https://console.aws.amazon.com

**지원 브라우저**:
- Google Chrome (권장)
- Mozilla Firefox
- Microsoft Edge
- Safari

#### 인증 방식

**IAM 사용자 로그인**:
1. 계정 ID 또는 별칭
2. IAM 사용자 이름
3. 비밀번호
4. (선택) MFA 코드

**루트 사용자 로그인**:
1. 이메일 주소
2. 비밀번호
3. (필수) MFA 코드

#### 콘솔 구성

**상단 네비게이션 바**:
```
┌─────────────────────────────────────────────────┐
│ AWS  [Services▼] [리전▼]  [알림] [계정▼] [지원] │
└─────────────────────────────────────────────────┘
```

**Services 메뉴**:
- 모든 AWS 서비스 목록
- 카테고리별 분류
- 최근 사용 서비스
- 즐겨찾기

**리전 선택**:
- 현재 리전 표시
- 리전 변경
- 글로벌 서비스는 리전 무관

**계정 메뉴**:
- 계정 정보
- 보안 자격 증명
- 결제 대시보드
- 로그아웃

#### 주요 기능

**1. 리소스 생성 및 관리**
```
예: EC2 인스턴스 생성
1. Services → Compute → EC2
2. "Launch Instance" 클릭
3. AMI 선택
4. 인스턴스 유형 선택
5. 네트워크 설정
6. 스토리지 추가
7. 태그 추가
8. 보안 그룹 설정
9. 검토 및 시작
```

**2. 리소스 모니터링**
- CloudWatch 대시보드
- 리소스 상태 확인
- 알람 설정

**3. 비용 확인**
- Billing Dashboard
- Cost Explorer
- 예산 설정

**4. 설정 변경**
- 리소스 수정
- 보안 설정
- 네트워크 구성

#### 장점과 단점

**장점**:
- ✅ 직관적이고 사용하기 쉬움
- ✅ 시각적으로 리소스 확인
- ✅ 초보자 친화적
- ✅ 설정 옵션 쉽게 탐색
- ✅ 즉시 사용 가능 (설치 불필요)

**단점**:
- ❌ 반복 작업 비효율적
- ❌ 자동화 불가능
- ❌ 대량 작업 어려움
- ❌ 스크립트 작성 불가

### 2.2 AWS CLI (Command Line Interface)

#### 개요

**정의**: 명령줄을 통해 AWS 서비스를 제어하는 도구

**지원 OS**:
- Linux
- macOS
- Windows

**버전**:
- AWS CLI v1 (레거시)
- AWS CLI v2 (현재, 권장)

#### 설치

**Linux**:
```bash
# 다운로드
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"

# 압축 해제
unzip awscliv2.zip

# 설치
sudo ./aws/install

# 확인
aws --version
```

**macOS**:
```bash
# Homebrew 사용
brew install awscli

# 또는 직접 설치
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"
sudo installer -pkg AWSCLIV2.pkg -target /

# 확인
aws --version
```

**Windows**:
```
1. AWS CLI MSI 설치 파일 다운로드
   https://awscli.amazonaws.com/AWSCLIV2.msi

2. 설치 파일 실행

3. 명령 프롬프트에서 확인
   aws --version
```

#### 인증 설정

**Access Key 생성** (IAM 콘솔에서):
```
1. IAM → Users → [사용자 선택]
2. "Security credentials" 탭
3. "Create access key" 클릭
4. 사용 사례 선택: "Command Line Interface (CLI)"
5. Access Key ID와 Secret Access Key 저장
```

**AWS CLI 설정**:
```bash
aws configure
```

입력 항목:
```
AWS Access Key ID [None]: AKIAIOSFODNN7EXAMPLE
AWS Secret Access Key [None]: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
Default region name [None]: ap-northeast-2
Default output format [None]: json
```

**설정 파일 위치**:
```
Linux/macOS:
~/.aws/credentials  (자격 증명)
~/.aws/config       (설정)

Windows:
C:\Users\USERNAME\.aws\credentials
C:\Users\USERNAME\.aws\config
```

**credentials 파일 내용**:
```ini
[default]
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

[user2]
aws_access_key_id = AKIAI44QH8DHBEXAMPLE
aws_secret_access_key = je7MtGbClwBF/2Zp9Utk/h3yCo8nvbEXAMPLEKEY
```

**config 파일 내용**:
```ini
[default]
region = ap-northeast-2
output = json

[profile user2]
region = us-east-1
output = table
```

#### 기본 사용법

**명령어 구조**:
```bash
aws <서비스> <명령> [옵션]
```

**예시**:
```bash
aws ec2 describe-instances
│   │   └─ 명령
│   └─ 서비스
└─ AWS CLI
```

#### 주요 명령어 예시

**EC2**:
```bash
# 인스턴스 목록 조회
aws ec2 describe-instances

# 인스턴스 시작
aws ec2 start-instances --instance-ids i-1234567890abcdef0

# 인스턴스 중지
aws ec2 stop-instances --instance-ids i-1234567890abcdef0

# 인스턴스 생성
aws ec2 run-instances \
    --image-id ami-0c55b159cbfafe1f0 \
    --instance-type t2.micro \
    --key-name MyKeyPair \
    --security-group-ids sg-903004f8 \
    --subnet-id subnet-6e7f829e
```

**S3**:
```bash
# 버킷 목록
aws s3 ls

# 버킷 생성
aws s3 mb s3://my-bucket

# 파일 업로드
aws s3 cp myfile.txt s3://my-bucket/

# 파일 다운로드
aws s3 cp s3://my-bucket/myfile.txt ./

# 버킷 동기화
aws s3 sync ./local-folder s3://my-bucket/

# 버킷 삭제
aws s3 rb s3://my-bucket --force
```

**IAM**:
```bash
# 사용자 목록
aws iam list-users

# 사용자 생성
aws iam create-user --user-name new-user

# 정책 연결
aws iam attach-user-policy \
    --user-name new-user \
    --policy-arn arn:aws:iam::aws:policy/ReadOnlyAccess
```

**RDS**:
```bash
# DB 인스턴스 목록
aws rds describe-db-instances

# DB 인스턴스 생성
aws rds create-db-instance \
    --db-instance-identifier mydb \
    --db-instance-class db.t3.micro \
    --engine mysql \
    --master-username admin \
    --master-user-password mypassword \
    --allocated-storage 20
```

#### 출력 형식

**JSON** (기본):
```bash
aws ec2 describe-instances --output json
```

**Table**:
```bash
aws ec2 describe-instances --output table
```

**Text**:
```bash
aws ec2 describe-instances --output text
```

**YAML**:
```bash
aws ec2 describe-instances --output yaml
```

#### 프로필 사용

**여러 계정/리전 관리**:
```bash
# 프로필 지정
aws ec2 describe-instances --profile user2

# 리전 지정
aws ec2 describe-instances --region us-west-2

# 프로필과 리전 동시 지정
aws ec2 describe-instances --profile user2 --region us-west-2
```

#### 장점과 단점

**장점**:
- ✅ 반복 작업 자동화
- ✅ 스크립트 작성 가능
- ✅ CI/CD 파이프라인 통합
- ✅ 빠른 작업 수행
- ✅ 배치 처리 가능

**단점**:
- ❌ 명령어 학습 필요
- ❌ 시각적 피드백 부족
- ❌ 초보자에게 어려움
- ❌ 설치 및 설정 필요

### 2.3 AWS SDK (Software Development Kit)

#### 개요

**정의**: 프로그래밍 언어를 통해 AWS 서비스를 제어하는 라이브러리

**목적**:
- 애플리케이션에서 AWS 서비스 사용
- 복잡한 로직 구현
- 자동화 및 통합

#### 지원 언어

| 언어 | SDK 이름 | 패키지 관리자 |
|------|---------|-------------|
| **Python** | Boto3 | pip |
| **JavaScript** | AWS SDK for JavaScript | npm |
| **Java** | AWS SDK for Java | Maven, Gradle |
| **C#/.NET** | AWS SDK for .NET | NuGet |
| **Go** | AWS SDK for Go | go get |
| **Ruby** | AWS SDK for Ruby | gem |
| **PHP** | AWS SDK for PHP | Composer |
| **C++** | AWS SDK for C++ | CMake |

#### Python (Boto3) 예시

**설치**:
```bash
pip install boto3
```

**인증**:
```python
# 방법 1: AWS CLI 설정 사용 (권장)
import boto3
s3 = boto3.client('s3')

# 방법 2: 코드에 직접 입력 (비권장)
s3 = boto3.client(
    's3',
    aws_access_key_id='YOUR_ACCESS_KEY',
    aws_secret_access_key='YOUR_SECRET_KEY',
    region_name='ap-northeast-2'
)
```

**S3 예시**:
```python
import boto3

# S3 클라이언트 생성
s3 = boto3.client('s3')

# 버킷 목록 조회
response = s3.list_buckets()
for bucket in response['Buckets']:
    print(f"Bucket: {bucket['Name']}")

# 파일 업로드
s3.upload_file('local-file.txt', 'my-bucket', 'remote-file.txt')

# 파일 다운로드
s3.download_file('my-bucket', 'remote-file.txt', 'downloaded-file.txt')

# 객체 목록
response = s3.list_objects_v2(Bucket='my-bucket')
for obj in response.get('Contents', []):
    print(f"File: {obj['Key']}, Size: {obj['Size']}")
```

**EC2 예시**:
```python
import boto3

# EC2 리소스 생성
ec2 = boto3.resource('ec2')

# 인스턴스 생성
instances = ec2.create_instances(
    ImageId='ami-0c55b159cbfafe1f0',
    MinCount=1,
    MaxCount=1,
    InstanceType='t2.micro',
    KeyName='MyKeyPair'
)

print(f"Created instance: {instances[0].id}")

# 인스턴스 목록
for instance in ec2.instances.all():
    print(f"ID: {instance.id}, State: {instance.state['Name']}")

# 인스턴스 중지
instance = ec2.Instance('i-1234567890abcdef0')
instance.stop()
```

**DynamoDB 예시**:
```python
import boto3

# DynamoDB 리소스
dynamodb = boto3.resource('dynamodb')

# 테이블 생성
table = dynamodb.create_table(
    TableName='Users',
    KeySchema=[
        {'AttributeName': 'user_id', 'KeyType': 'HASH'}
    ],
    AttributeDefinitions=[
        {'AttributeName': 'user_id', 'AttributeType': 'S'}
    ],
    BillingMode='PAY_PER_REQUEST'
)

# 아이템 추가
table = dynamodb.Table('Users')
table.put_item(
    Item={
        'user_id': '123',
        'name': 'John Doe',
        'email': 'john@example.com'
    }
)

# 아이템 조회
response = table.get_item(Key={'user_id': '123'})
print(response['Item'])
```

#### Node.js 예시

**설치**:
```bash
npm install aws-sdk
```

**사용**:
```javascript
const AWS = require('aws-sdk');

// 리전 설정
AWS.config.update({region: 'ap-northeast-2'});

// S3 클라이언트
const s3 = new AWS.S3();

// 버킷 목록
s3.listBuckets((err, data) => {
    if (err) console.log(err);
    else {
        data.Buckets.forEach(bucket => {
            console.log(`Bucket: ${bucket.Name}`);
        });
    }
});

// 파일 업로드
const params = {
    Bucket: 'my-bucket',
    Key: 'file.txt',
    Body: 'Hello World!'
};

s3.upload(params, (err, data) => {
    if (err) console.log(err);
    else console.log(`File uploaded: ${data.Location}`);
});
```

#### 장점과 단점

**장점**:
- ✅ 애플리케이션 완전 통합
- ✅ 복잡한 로직 구현
- ✅ 에러 처리 및 재시도
- ✅ 타입 안전성 (일부 언어)
- ✅ 대규모 자동화

**단점**:
- ❌ 프로그래밍 지식 필요
- ❌ 개발 및 테스트 시간
- ❌ 디버깅 복잡
- ❌ 의존성 관리

### 2.4 접근 방법 비교 및 선택 가이드

| 구분 | Console | CLI | SDK |
|------|---------|-----|-----|
| **인터페이스** | GUI (웹) | 명령줄 | 프로그래밍 코드 |
| **인증** | ID + 비밀번호 | Access Key | Access Key |
| **설치** | 불필요 | 필요 | 필요 |
| **난이도** | 쉬움 | 중간 | 어려움 |
| **자동화** | 불가능 | 가능 | 가능 |
| **반복 작업** | 비효율적 | 효율적 | 매우 효율적 |
| **학습 곡선** | 낮음 | 중간 | 높음 |
| **사용 사례** | 탐색, 수동 작업 | 스크립트, 자동화 | 애플리케이션 통합 |

**선택 가이드**:

**Console 사용 시기**:
- 처음 AWS 학습할 때
- 리소스 상태 시각적 확인
- 일회성 작업
- 설정 옵션 탐색

**CLI 사용 시기**:
- 반복적인 작업
- 배치 스크립트
- CI/CD 파이프라인
- 빠른 명령 실행

**SDK 사용 시기**:
- 애플리케이션 개발
- 복잡한 비즈니스 로직
- 대규모 자동화
- 커스텀 도구 개발

---

## 3. AWS 비용 관리 도구

### 3.1 비용 관리의 중요성

#### 왜 비용 관리가 필요한가?

**1. 예상치 못한 비용 증가**
```
사례:
- 테스트 EC2 인스턴스를 중지하지 않고 방치
- 월 예상 비용: $50
- 실제 청구: $1,500
- 원인: 24/7 실행 + 대용량 EBS
```

**2. 리소스 낭비**
```
- 사용하지 않는 EBS 볼륨
- 삭제된 인스턴스의 Elastic IP
- 오래된 스냅샷
- 미사용 로드 밸런서
```

**3. 보안 위협**
```
- 계정 탈취 시 악의적 리소스 생성
- 비트코인 채굴용 대량 인스턴스
- 수백만 원의 청구서
```

**4. 비용 귀속 불명확**
```
- 여러 팀이 같은 계정 사용
- 누가 얼마나 사용했는지 불명확
- 비용 청구 및 예산 관리 어려움
```

### 3.2 AWS Billing and Cost Management

**접근 방법**:
```
1. AWS Console 로그인
2. 우측 상단 계정 이름 클릭
3. "Billing and Cost Management" 선택
```

**주요 기능 그룹**:

#### 1. 비용 가시성 및 보고

**Cost Explorer**

**기능**:
- 비용 및 사용량 시각화
- 시간별, 일별, 월별 추이
- 서비스, 리전, 계정별 필터링
- 미래 비용 예측

**사용 예시**:
```
질문: "지난 3개월간 EC2 비용이 얼마나 증가했는가?"

1. Cost Explorer 열기
2. 기간: 지난 3개월
3. 그룹화: 서비스
4. 필터: EC2
5. 그래프 확인
```

**비용 및 사용 보고서 (CUR - Cost and Usage Report)**

**특징**:
- 가장 상세한 비용 데이터
- 시간별 사용량
- 모든 리소스 태그 포함
- S3에 CSV 파일로 저장

**활용**:
```
1. S3 버킷에 CUR 저장
2. Amazon Athena로 SQL 쿼리
3. QuickSight로 시각화
4. 커스텀 대시보드 구축
```

#### 2. 비용 최적화

**예약 인스턴스 (Reserved Instances, RI)**

**개념**:
- 1년 또는 3년 약정
- 온디맨드 대비 최대 75% 할인

**유형**:
```
Standard RI:
- 최대 할인율
- 인스턴스 유형 변경 불가

Convertible RI:
- 중간 할인율
- 인스턴스 유형 변경 가능

Scheduled RI:
- 특정 시간대만 예약
- 예: 업무 시간 (9AM-6PM)
```

**절감형 플랜 (Savings Plans)**

**특징**:
- 시간당 사용량 약정 (예: $10/시간)
- 더 유연한 할인
- EC2, Lambda, Fargate 적용

**Cost Anomaly Detection**

**기능**:
- 머신러닝 기반 비정상 비용 감지
- 평소 패턴에서 벗어난 지출 알림

**예시**:
```
평소 패턴: 월 $500
이번 달 예상: $2,000

→ 자동 알림 발송
→ 원인 조사
→ 불필요한 리소스 삭제
```

**Cost Allocation Tags**

**개념**:
- 리소스에 태그 지정
- 태그별 비용 추적

**예시**:
```
태그:
- Environment: Production
- Project: WebApp
- Team: Backend
- CostCenter: Engineering

비용 보고서:
- WebApp 프로젝트: $1,200
- Backend 팀: $800
- Engineering 부서: $3,500
```

#### 3. 재무 관리 및 알림

**AWS Budgets**

**기능**:
- 예산 설정
- 임계값 알림
- 실제 및 예상 비용 추적

**예산 유형**:
```
1. 비용 예산:
   - 월 $500 예산
   - 80% ($400) 도달 시 경고
   - 100% ($500) 도달 시 긴급 알림

2. 사용량 예산:
   - EC2 시간: 월 1,000시간
   - 80% 사용 시 알림

3. 예약 예산:
   - RI 사용률 목표: 80%
   - 미달 시 알림
```

**설정 예시**:
```
1. Budgets 콘솔
2. "Create budget" 클릭
3. 예산 유형: Cost budget
4. 금액: $500
5. 알림 설정:
   - 80% 도달: 이메일
   - 100% 도달: 이메일 + SNS
   - 120% 초과 예상: 긴급 알림
6. 생성
```

**청구서 (Invoices)**

**기능**:
- 월별 최종 청구서
- PDF 다운로드
- 서비스별 상세 내역

### 3.3 비용 절감 전략

**1. 사용하지 않는 리소스 삭제**
```
체크리스트:
☐ 중지된 EC2 인스턴스 (EBS 비용 발생)
☐ 연결되지 않은 EBS 볼륨
☐ 오래된 스냅샷
☐ 미사용 Elastic IP
☐ 미사용 로드 밸런서
☐ 빈 S3 버킷
```

**2. 적절한 인스턴스 크기 선택**
```
과도한 크기:
- t3.2xlarge (8 vCPU, 32GB RAM)
- CPU 사용률: 5%
- 월 비용: $240

적절한 크기:
- t3.medium (2 vCPU, 4GB RAM)
- CPU 사용률: 20%
- 월 비용: $30
- 절감: $210/월
```

**3. 예약 인스턴스 활용**
```
온디맨드:
- t3.medium 24/7
- 시간당: $0.0416
- 월 비용: $30

1년 예약:
- 선불: $200
- 시간당: $0.01
- 월 비용: $7.2
- 총 비용 (1년): $200 + $86.4 = $286.4
- 온디맨드 (1년): $360
- 절감: $73.6 (20%)
```

**4. 스팟 인스턴스 활용**
```
용도: 중단 가능한 워크로드
- 배치 처리
- 데이터 분석
- CI/CD

할인율: 최대 90%
```

**5. S3 스토리지 클래스 최적화**
```
자주 액세스:
- S3 Standard
- $0.023/GB

가끔 액세스:
- S3 Standard-IA
- $0.0125/GB
- 절감: 45%

아카이브:
- S3 Glacier
- $0.004/GB
- 절감: 82%
```

---

## 4. AWS 시스템 구축 위치 선택

### 4.1 리전 선택 전략 (복습 및 심화)

#### 지연시간 최적화

**측정 도구**:
```
AWS CloudPing:
- https://www.cloudping.info/
- 각 리전까지의 지연시간 측정
```

**예시**:
```
서울에서 측정:
- ap-northeast-2 (서울): 2ms
- ap-northeast-1 (도쿄): 35ms
- us-west-2 (오레곤): 120ms
- eu-west-1 (아일랜드): 280ms
```

#### 법적 요구사항

**데이터 주권 시나리오**:
```
한국 금융 서비스:
- 고객 데이터: 서울 리전 (필수)
- 백업: 서울 리전 (권장)
- 개발/테스트: 다른 리전 가능

EU GDPR:
- EU 시민 데이터: EU 리전 (필수)
- 데이터 전송 제한
```

#### 가용 서비스 확인

**확인 방법**:
```
1. AWS Regional Services 페이지 방문
2. 리전 선택
3. 사용 가능한 서비스 확인
```

#### 비용 최적화

**다중 리전 전략**:
```
프로덕션: 서울 리전 (사용자 근처)
개발/테스트: 미국 리전 (저렴)
백업: 저렴한 리전
```

### 4.2 가용 영역 배치 전략

#### 고가용성 아키텍처

**3-Tier 웹 애플리케이션**:
```
리전: ap-northeast-2

AZ-A (ap-northeast-2a):
├─ 퍼블릭 서브넷: 10.0.1.0/24
│  └─ 웹 서버 1, NAT Gateway
├─ 프라이빗 서브넷: 10.0.2.0/24
│  └─ 앱 서버 1
└─ 데이터베이스 서브넷: 10.0.3.0/24
   └─ RDS Primary

AZ-B (ap-northeast-2b):
├─ 퍼블릭 서브넷: 10.0.11.0/24
│  └─ 웹 서버 2, NAT Gateway
├─ 프라이빗 서브넷: 10.0.12.0/24
│  └─ 앱 서버 2
└─ 데이터베이스 서브넷: 10.0.13.0/24
   └─ RDS Standby

AZ-C (ap-northeast-2c):
├─ 퍼블릭 서브넷: 10.0.21.0/24
│  └─ 웹 서버 3
└─ 프라이빗 서브넷: 10.0.22.0/24
   └─ 앱 서버 3
```

#### 비용 vs 가용성 균형

**옵션 1: 최소 비용 (단일 AZ)**
```
장점: 저렴
단점: 낮은 가용성
권장: 개발/테스트 환경
```

**옵션 2: 균형 (2 AZ)**
```
장점: 적절한 비용, 좋은 가용성
단점: 한 AZ 전체 장애 시 성능 저하
권장: 중소규모 프로덕션
```

**옵션 3: 최고 가용성 (3+ AZ)**
```
장점: 최고 가용성
단점: 높은 비용
권장: 미션 크리티컬 시스템
```

---

## 5. 요약

### 핵심 개념 정리

**AWS 계정**:
- 루트 사용자: 모든 권한, MFA 필수, 일상 작업 금지
- IAM 사용자: 제한된 권한, 일상 작업용

**접근 방법**:
- Console: GUI, 초보자 친화적
- CLI: 명령줄, 자동화 가능
- SDK: 프로그래밍, 애플리케이션 통합

**비용 관리**:
- Cost Explorer: 비용 시각화
- Budgets: 예산 및 알림
- RI/SP: 장기 약정 할인
- 태그: 비용 추적

**위치 선택**:
- 리전: 지연시간, 법규, 서비스, 비용
- 다중 AZ: 고가용성

### 학습 체크리스트

- [ ] AWS 계정을 생성할 수 있다
- [ ] 루트 사용자와 IAM 사용자의 차이를 안다
- [ ] MFA를 설정할 수 있다
- [ ] Console, CLI, SDK의 차이를 설명할 수 있다
- [ ] AWS CLI를 설치하고 설정할 수 있다
- [ ] 기본 CLI 명령어를 사용할 수 있다
- [ ] 비용 관리 도구를 활용할 수 있다
- [ ] 예산 알림을 설정할 수 있다
- [ ] 리전과 AZ를 선택할 수 있다

---

**이전 챕터**: [Chapter 1: AWS 기초 지식](./Chapter01_AWS기초지식_상세.md)  
**다음 챕터**: [Chapter 3: IAM 서비스](./Chapter03_IAM서비스_상세.md)
