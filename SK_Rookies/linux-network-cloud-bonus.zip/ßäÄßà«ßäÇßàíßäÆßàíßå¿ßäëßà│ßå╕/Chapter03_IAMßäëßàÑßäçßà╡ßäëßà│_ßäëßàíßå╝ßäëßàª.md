# Chapter 03: IAM - 권한과 보안의 핵심

> **이 챕터의 목표**
> AWS의 모든 권한 관리 체계인 IAM을 완벽하게 이해합니다.
> 인증/인가 개념을 OS, 네트워크 수준과 비교하며 심층 분석합니다.
> 정책, ARN, SCP 등 AWS 권한의 모든 측면을 마스터합니다.

---

## 목차
1. [인증과 인가의 본질](#1-인증과-인가의-본질)
2. [AWS IAM 개요](#2-aws-iam-개요)
3. [IAM 사용자, 그룹, 역할 심화](#3-iam-사용자-그룹-역할-심화)
4. [IAM 정책의 완벽한 이해](#4-iam-정책의-완벽한-이해)
5. [AWS 권한 종류 상세](#5-aws-권한-종류-상세)
6. [ARN - Amazon Resource Name](#6-arn---amazon-resource-name)
7. [SCP와 조직 권한 관리](#7-scp와-조직-권한-관리)
8. [최소 권한 원칙과 보안](#8-최소-권한-원칙과-보안)

---

## 1. 인증과 인가의 본질

### 1.1 인증 (Authentication) vs 인가 (Authorization)

이 두 개념은 AWS뿐만 아니라 모든 컴퓨터 시스템의 보안 기반입니다.

#### 인증 (Authentication) - "당신은 누구인가?"

**정의:** 사용자의 신원을 확인하는 과정

```mermaid
graph LR
    A[사용자] -->|"나는 홍길동입니다"| B[시스템]
    B -->|"증명해보세요"| A
    A -->|비밀번호/생체정보/인증서| B
    B -->|검증 성공| C[신원 확인 완료]
```

**일상 생활의 예:**
- 은행에서 신분증 제시
- 아파트 출입 시 카드 태그
- 휴대폰 잠금 해제 (지문, 얼굴)

**컴퓨터 시스템의 인증 방법:**

1. **지식 기반 (Something You Know)**
   ```
   - 비밀번호
   - PIN 번호
   - 보안 질문 답변

   장점: 구현 간단
   단점: 잊어버림, 추측/도청 가능
   ```

2. **소유 기반 (Something You Have)**
   ```
   - OTP 토큰
   - 스마트카드
   - USB 보안 키
   - 휴대폰 (SMS 인증)

   장점: 물리적 소유 필요
   단점: 분실/도난 위험
   ```

3. **생체 기반 (Something You Are)**
   ```
   - 지문
   - 얼굴 인식
   - 홍채 인식
   - 음성 인식

   장점: 복제 어려움, 분실 불가
   단점: 비용, 프라이버시 우려
   ```

4. **다중 인증 (Multi-Factor Authentication, MFA)**
   ```
   두 가지 이상 결합:
   - 비밀번호 + OTP
   - 지문 + PIN

   예: AWS 루트 계정 = 비밀번호 + MFA 디바이스
   ```

#### 인가 (Authorization) - "무엇을 할 수 있는가?"

**정의:** 인증된 사용자가 어떤 리소스에 접근하고 어떤 작업을 수행할 수 있는지 결정

```mermaid
graph TD
    A[인증 완료:<br/>홍길동으로 확인됨] --> B[인가 확인]
    B --> C{S3 버킷 읽기?}
    C -->|정책 확인| D{권한 있음?}
    D -->|Yes| E[허용]
    D -->|No| F[거부]
```

**일상 생활의 예:**
- 회사 사원증: 내 부서 출입 가능, 다른 부서 불가
- 신용카드: 한도 내에서만 결제 가능
- 운전면허: 1종/2종에 따라 운전 가능 차량 다름

### 1.2 운영체제(OS)의 권한 시스템과 비교

#### Linux/Unix 파일 권한

```bash
$ ls -l /var/log/syslog
-rw-r----- 1 syslog adm 1048576 Dec 11 10:00 syslog
│││││││││
│││││││││
│││└┴┴┴┴─ 권한 비트
││└─────── 그룹 (adm)
│└──────── 소유자 (syslog)
└───────── 파일 타입 (- = 일반 파일)

권한 비트: rwx r-x r--
           │   │   │
           │   │   └─ 기타 (others): 읽기만
           │   └───── 그룹 (adm): 읽기 + 실행
           └───────── 소유자 (syslog): 읽기 + 쓰기 + 실행
```

**Linux 권한의 3가지 주체:**
- **User (u)**: 파일 소유자
- **Group (g)**: 파일 그룹
- **Others (o)**: 그 외 모두

**Linux 권한의 3가지 유형:**
- **Read (r, 4)**: 읽기
- **Write (w, 2)**: 쓰기
- **Execute (x, 1)**: 실행

**예시:**
```bash
chmod 644 file.txt
# 6 (4+2) = rw-  (소유자: 읽기+쓰기)
# 4       = r--  (그룹: 읽기만)
# 4       = r--  (기타: 읽기만)

chmod 755 script.sh
# 7 (4+2+1) = rwx  (소유자: 모두)
# 5 (4+1)   = r-x  (그룹: 읽기+실행)
# 5 (4+1)   = r-x  (기타: 읽기+실행)
```

#### AWS IAM과 Linux 권한 비교

```mermaid
graph TD
    subgraph "Linux 파일 시스템"
        L1[주체:<br/>User, Group, Others]
        L2[객체:<br/>File, Directory]
        L3[권한:<br/>Read, Write, Execute]
    end

    subgraph "AWS IAM"
        A1[주체:<br/>User, Group, Role]
        A2[객체:<br/>AWS Resource<br/>EC2, S3, RDS 등]
        A3[권한:<br/>정책 Policy<br/>수백 가지 작업]
    end

    L1 -.유사.-> A1
    L2 -.유사.-> A2
    L3 -.유사.-> A3
```

**주요 차이점:**

| 특성 | Linux | AWS IAM |
|------|-------|---------|
| **권한 세분화** | 3가지 (r, w, x) | 수천 가지 (s3:GetObject, ec2:RunInstances 등) |
| **권한 부여 방식** | 숫자/문자 (chmod 644) | JSON 정책 문서 |
| **상속** | 디렉토리 기본 권한 | 그룹 정책 상속 |
| **조건부 권한** | 제한적 (ACL) | 매우 강력 (IP, 시간, MFA 등) |
| **권한 범위** | 단일 시스템 | 클라우드 전체 |

### 1.3 네트워크 접근 제어와 비교

#### 방화벽 (Firewall)

```mermaid
graph LR
    A[인터넷] -->|Port 80/443| B[방화벽]
    B -->|허용| C[웹 서버]
    A -->|Port 22| B
    B -->|차단| D[관리 네트워크]
```

**방화벽 규칙 예시 (iptables):**
```bash
# SSH 포트 22번을 특정 IP에서만 허용
iptables -A INPUT -p tcp --dport 22 -s 203.0.113.0/24 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j DROP

# HTTP/HTTPS는 모두 허용
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
```

**AWS Security Group과 비교:**

| 특성 | 방화벽 (iptables) | AWS Security Group |
|------|-------------------|-------------------|
| **기본 정책** | DROP (모두 차단) | DENY (모두 차단) |
| **허용 규칙** | ACCEPT | Allow |
| **거부 규칙** | DROP/REJECT | 없음 (허용만 가능) |
| **상태 추적** | 가능 (stateful/stateless 선택) | Stateful (자동) |
| **적용 대상** | 네트워크 인터페이스 | EC2 인스턴스 |

**중요한 차이:**
- 방화벽: 명시적 허용 + 명시적 거부 가능
- Security Group: 명시적 허용만 (허용 안 하면 자동 거부)
- NACL (Network ACL): 방화벽과 유사 (허용 + 거부 모두 가능)

### 1.4 데이터베이스 권한과 비교

#### MySQL 권한 시스템

```sql
-- 사용자 생성
CREATE USER 'developer'@'localhost' IDENTIFIED BY 'password';

-- 특정 데이터베이스의 특정 테이블에만 권한 부여
GRANT SELECT, INSERT ON myapp.users TO 'developer'@'localhost';

-- 모든 권한 부여
GRANT ALL PRIVILEGES ON myapp.* TO 'admin'@'localhost';

-- 권한 확인
SHOW GRANTS FOR 'developer'@'localhost';
```

**MySQL 권한 계층:**
```
글로벌 (Global) - 서버 전체
    ↓
데이터베이스 (Database) - 특정 DB
    ↓
테이블 (Table) - 특정 테이블
    ↓
컬럼 (Column) - 특정 컬럼
```

**AWS IAM과 비교:**

```mermaid
graph TD
    subgraph "MySQL"
        M1[계정]
        M2[데이터베이스]
        M3[테이블]
        M4[권한: SELECT, INSERT, UPDATE, DELETE]
    end

    subgraph "AWS IAM"
        A1[IAM User/Role]
        A2[AWS Account]
        A3[서비스: S3, EC2, RDS]
        A4[리소스: 버킷, 인스턴스, DB]
        A5[권한: s3:GetObject, ec2:RunInstances]
    end

    M1 -.유사.-> A1
    M2 -.유사.-> A2
    M3 -.유사.-> A3
    M4 -.유사.-> A5
```

### 1.5 인증 프로토콜들

#### Kerberos (Active Directory)

기업 환경에서 널리 사용되는 인증 프로토콜:

```mermaid
sequenceDiagram
    participant U as 사용자
    participant AS as 인증 서버<br/>(AS)
    participant TGS as 티켓 발급 서버<br/>(TGS)
    participant S as 서비스<br/>(파일 서버)

    U->>AS: 1. 로그인 요청 (사용자명)
    AS->>U: 2. TGT (Ticket Granting Ticket)
    Note over U: TGT는 하루 종일 유효

    U->>TGS: 3. 서비스 티켓 요청 (TGT 제시)
    TGS->>U: 4. 서비스 티켓

    U->>S: 5. 서비스 접근 (서비스 티켓 제시)
    S->>U: 6. 접근 허용
```

**특징:**
- Single Sign-On (SSO): 한 번 로그인으로 여러 서비스 접근
- 티켓 기반: 비밀번호를 서비스에 직접 전송하지 않음
- 시간 제한: 티켓 만료 시간

**AWS와의 연동:**
- AWS IAM Identity Center (구 AWS SSO)
- SAML 2.0 페더레이션
- Active Directory Connector

#### OAuth 2.0 / OpenID Connect

현대 웹/모바일 애플리케이션의 표준:

```mermaid
sequenceDiagram
    participant U as 사용자
    participant C as 클라이언트<br/>(앱)
    participant Auth as 인증 서버<br/>(구글, 페이스북)
    participant API as API 서버

    U->>C: 1. "구글로 로그인" 클릭
    C->>Auth: 2. 인증 요청 (리다이렉트)
    Auth->>U: 3. 로그인 페이지 표시
    U->>Auth: 4. 자격 증명 입력
    Auth->>U: 5. 권한 부여 동의
    Auth->>C: 6. 인증 코드 (리다이렉트)
    C->>Auth: 7. 액세스 토큰 요청 (코드 + 시크릿)
    Auth->>C: 8. 액세스 토큰 + 리프레시 토큰
    C->>API: 9. API 요청 (액세스 토큰)
    API->>C: 10. 데이터 응답
```

**AWS Cognito와의 관계:**
- Cognito User Pool: 자체 사용자 디렉토리
- Cognito Identity Pool: 페더레이션 (구글, 페이스북 등)
- OAuth 2.0/OIDC 지원

---

## 2. AWS IAM 개요

### 2.1 IAM이란 무엇인가?

**IAM (Identity and Access Management):**
- AWS 리소스에 대한 **액세스를 안전하게 제어**하는 웹 서비스
- "누가(Who), 무엇을(What), 어떻게(How)" 접근할 수 있는지 정의

```mermaid
graph TD
    A[IAM] --> B[인증<br/>Authentication]
    A --> C[인가<br/>Authorization]
    A --> D[감사<br/>Audit]

    B --> B1[사용자 신원 확인]
    C --> C1[권한 부여/거부]
    D --> D1[모든 작업 로깅<br/>CloudTrail]
```

### 2.2 IAM의 특징

#### 1. 무료 서비스

```
IAM 사용에 대한 추가 비용 없음
- 사용자/그룹/역할 무제한 생성
- 정책 무제한 생성
- 단, 사용한 AWS 리소스에 대한 비용은 발생
```

#### 2. 글로벌 서비스

```mermaid
graph TD
    A[IAM] -.-> B[미국 동부<br/>us-east-1]
    A -.-> C[아시아 태평양<br/>ap-northeast-2]
    A -.-> D[유럽<br/>eu-west-1]
    A -.-> E[모든 리전]

    style A fill:#e1f5ff

    Note[IAM은 리전 선택 불필요<br/>전 세계 모든 리전에서 동일하게 적용]
```

**의미:**
- IAM 사용자/역할/정책은 **모든 리전에서 동일**
- 서울 리전에서 만든 사용자가 버지니아 리전의 EC2도 관리 가능
- 리전별로 따로 설정할 필요 없음

**예외: 일부 STS (Security Token Service) 엔드포인트**
- STS는 리전별 엔드포인트 존재 (성능 최적화용)
- 하지만 IAM 자체는 글로벌

#### 3. 세밀한 권한 제어

```
리소스 수준까지 권한 지정 가능:

예시 1: S3 버킷의 특정 폴더만 접근
- my-bucket/user1/* : 허용
- my-bucket/user2/* : 거부

예시 2: 특정 태그가 있는 EC2만 중지
- Tag: Environment=Dev : 허용
- Tag: Environment=Prod : 거부

예시 3: 특정 시간대에만 접근
- 09:00-18:00 : 허용
- 그 외 시간 : 거부
```

#### 4. 임시 자격 증명

```mermaid
graph LR
    A[IAM Role] -->|AssumeRole| B[임시 자격 증명<br/>Temporary Credentials]
    B --> C[Access Key ID]
    B --> D[Secret Access Key]
    B --> E[Session Token]
    B --> F[만료 시간<br/>15분 ~ 12시간]

    style B fill:#ffe1e1
```

**영구 자격 증명의 문제:**
```
IAM User Access Key:
- AKIA... (Access Key ID)
- wJalrXUtn... (Secret Access Key)
- 삭제 전까지 영구 유효
- 노출 시 큰 위험
```

**임시 자격 증명의 장점:**
```
IAM Role 임시 자격 증명:
- ASIA... (Access Key ID)
- wJalrXUtn... (Secret Access Key)
- IQoJb3JpZ... (Session Token)
- 만료 시간: 1시간
- 노출되어도 1시간 후 무효화
```

### 2.3 IAM의 구성 요소

```mermaid
graph TD
    A[AWS Account] --> B[IAM Users<br/>사용자]
    A --> C[IAM Groups<br/>그룹]
    A --> D[IAM Roles<br/>역할]
    A --> E[IAM Policies<br/>정책]

    B -.소속.-> C
    C -.할당.-> E
    B -.할당.-> E
    D -.할당.-> E

    F[AWS Services] -.assume.-> D
    G[External Users] -.assume.-> D
```

**각 구성 요소의 역할:**

1. **IAM User (사용자)**
   - 개인 또는 애플리케이션
   - 영구적 자격 증명
   - 콘솔 로그인 또는 API 접근

2. **IAM Group (그룹)**
   - 사용자의 집합
   - 정책을 그룹에 부여하면 모든 멤버 상속
   - 사용자 관리 간소화

3. **IAM Role (역할)**
   - 임시 자격 증명
   - AWS 서비스, 외부 사용자가 assume (맡음)
   - 비밀번호/Access Key 없음

4. **IAM Policy (정책)**
   - 권한을 정의하는 문서
   - 사용자/그룹/역할에 연결
   - JSON 형식

### 2.4 루트 사용자 (Root User)

```mermaid
graph TD
    A[AWS 계정 생성] --> B[루트 사용자<br/>Root User]

    B --> C[완전한 권한<br/>모든 리소스 접근]
    B --> D[계정 수준 작업<br/>IAM으로 제한 불가]

    D --> D1[결제 정보 변경]
    D --> D2[계정 폐쇄]
    D --> D3[서포트 플랜 변경]
    D --> D4[루트 자격 증명 변경]

    style B fill:#ffe1e1
    style D fill:#ffe1e1
```

**루트 사용자의 특징:**
- AWS 계정 생성 시 자동으로 만들어짐
- 이메일 주소로 로그인
- **제한할 수 없는 완전한 권한**
- IAM 정책으로도 제한 불가

**루트 사용자만 할 수 있는 작업:**
```
1. 계정 설정 변경
   - 계정 이름
   - 이메일 주소
   - 루트 비밀번호

2. 결제 관련
   - 결제 정보 수정
   - 세금 설정
   - AWS Organizations 결제 설정

3. 계정 관리
   - AWS 계정 폐쇄
   - AWS Support 플랜 변경

4. 일부 서비스의 작업
   - CloudFront 키 페어 관리
   - S3 버킷 정책에서 MFA Delete 활성화
```

**루트 사용자 보안 모범 사례:**

```mermaid
graph TD
    A[루트 사용자 보안] --> B[1. MFA 필수 설정]
    A --> C[2. Access Key 생성 금지]
    A --> D[3. 일상 작업 사용 금지]
    A --> E[4. 강력한 비밀번호]
    A --> F[5. 관리자 IAM 사용자 생성]

    B --> B1[가상 MFA: Google Authenticator]
    B --> B2[하드웨어 MFA: YubiKey]

    C --> C1[프로그래밍 방식 접근 금지]

    D --> D1[일상 작업은 IAM 사용자로]

    F --> F1[AdministratorAccess 정책]
    F --> F2[MFA 필수]
```

**잘못된 사용 예:**
```bash
# ❌ 나쁜 예: 루트 Access Key로 AWS CLI 사용
$ aws configure
AWS Access Key ID: AKIA... (루트 계정)
AWS Secret Access Key: ****

# ✅ 좋은 예: IAM 사용자로 AWS CLI 사용
$ aws configure --profile admin
AWS Access Key ID: AKIA... (IAM 관리자 사용자)
AWS Secret Access Key: ****
```

### 2.5 IAM의 보안 원칙

#### 1. 최소 권한 원칙 (Principle of Least Privilege)

```mermaid
graph TD
    A[사용자/서비스] --> B{필요한 권한은?}
    B --> C[EC2 시작/중지만 필요]
    C --> D[EC2 시작/중지 권한만 부여]

    E[❌ 잘못된 접근] --> F[AdministratorAccess<br/>모든 권한 부여]

    style F fill:#ffe1e1
    style D fill:#e1ffe1
```

**왜 중요한가?**
```
1. 보안 침해 시 피해 최소화
   - 계정 탈취되어도 할 수 있는 일 제한

2. 실수 방지
   - 프로덕션 리소스 삭제 실수 예방

3. 규정 준수
   - SOC2, ISO27001 등 요구사항
```

**예시: 개발자 권한**

❌ **나쁜 예:**
```
개발자에게 AdministratorAccess 부여
→ 실수로 프로덕션 DB 삭제 가능
→ 결제 정보 조회 가능
→ 다른 사용자 권한 변경 가능
```

✅ **좋은 예:**
```
개발자에게 필요한 권한만:
- EC2: 개발 환경 인스턴스만 관리
- S3: 개발 버킷만 접근
- RDS: 개발 DB만 접근 (읽기 전용)
- CloudWatch Logs: 로그 조회만
```

#### 2. 역할 분리 (Separation of Duties)

```mermaid
graph LR
    A[개발자] -->|코드 작성| B[개발 환경]
    C[운영자] -->|배포/관리| D[프로덕션 환경]
    E[보안 관리자] -->|권한 관리| F[IAM]

    A -.X.-> D
    C -.X.-> F
    E -.X.-> B
```

**중요한 역할들:**

```
1. 개발자 (Developer)
   - 개발 환경 리소스 관리
   - 코드 작성, 테스트
   - 프로덕션 읽기 전용

2. 운영자 (Operator)
   - 프로덕션 배포
   - 모니터링, 알람
   - 인프라 관리
   - IAM 권한 없음

3. 보안 관리자 (Security Admin)
   - IAM 정책 관리
   - 보안 그룹 설정
   - 로그 분석
   - 리소스 생성 권한 없음

4. 재무 관리자 (Billing Admin)
   - 비용 조회
   - 예산 설정
   - 리소스 생성/삭제 권한 없음
```

#### 3. 감사 가능성 (Auditability)

```mermaid
graph TD
    A[모든 IAM 작업] --> B[CloudTrail에 기록]

    B --> C[누가]
    B --> D[언제]
    B --> E[무엇을]
    B --> F[어디서]

    C --> G[예: user1@example.com]
    D --> H[예: 2024-12-11 10:30:15 UTC]
    E --> I[예: DeleteBucket]
    F --> J[예: IP 203.0.113.10]

    G --> K[감사 리포트 생성]
    H --> K
    I --> K
    J --> K
```

**CloudTrail 로그 예시:**
```
이벤트: S3 버킷 삭제
시간: 2024-12-11T10:30:15Z
사용자: arn:aws:iam::123456789012:user/developer1
작업: s3:DeleteBucket
리소스: arn:aws:s3:::my-prod-bucket
결과: 성공
IP: 203.0.113.10
사용자 에이전트: aws-cli/2.13.0
```

**감사의 중요성:**
```
1. 보안 사고 조사
   - 누가 데이터를 삭제했는가?
   - 언제 권한이 변경되었는가?

2. 규정 준수
   - SOC 2, PCI DSS 요구사항
   - 모든 접근 기록 보관

3. 이상 탐지
   - 비정상적인 접근 패턴
   - 권한 남용
```

---

## 3. IAM 사용자, 그룹, 역할 심화

### 3.1 IAM 사용자 (User)

#### 사용자의 본질

**정의:** AWS 서비스를 사용하는 **개인 또는 애플리케이션**을 나타내는 엔터티

```mermaid
graph TD
    A[IAM User] --> B[사람<br/>Person]
    A --> C[애플리케이션<br/>Application]

    B --> B1[콘솔 접근<br/>비밀번호]
    B --> B2[CLI/SDK<br/>Access Key]

    C --> C1[서버 앱<br/>Access Key]
    C --> C2[배치 작업<br/>Access Key]

    style B1 fill:#e1f5ff
    style B2 fill:#e1f5ff
    style C1 fill:#ffe1e1
    style C2 fill:#ffe1e1

    Note[애플리케이션용으로는<br/>IAM Role 사용 권장]
```

**사용자의 특징:**

1. **영구적 자격 증명**
   ```
   - 비밀번호: 삭제 전까지 영구 유효
   - Access Key: 삭제 전까지 영구 유효
   - 보안 위험: 노출 시 오랜 기간 악용 가능
   ```

2. **두 가지 접근 방식**
   ```
   A. 콘솔 접근 (Console Access):
      - 웹 브라우저로 AWS Management Console 로그인
      - 사용자 이름 + 비밀번호
      - 선택적: MFA (Multi-Factor Authentication)

   B. 프로그래밍 방식 접근 (Programmatic Access):
      - AWS CLI, SDK, API 직접 호출
      - Access Key ID + Secret Access Key
      - 코드에 하드코딩 금지!
   ```

3. **고유 식별자**
   ```
   사용자 이름: developer1
   ARN: arn:aws:iam::123456789012:user/developer1
   Unique ID: AIDACKCEVSQ6C2EXAMPLE
   ```

#### 사용자 생성 과정

```mermaid
sequenceDiagram
    participant Admin as 관리자
    participant IAM as IAM 서비스
    participant User as 새 사용자

    Admin->>IAM: 1. 사용자 생성 요청<br/>(이름: developer1)
    IAM->>IAM: 2. 고유 ID 생성
    Admin->>IAM: 3. 접근 방식 선택<br/>(콘솔 + 프로그래밍)
    IAM->>IAM: 4. 자격 증명 생성<br/>(비밀번호 + Access Key)
    Admin->>IAM: 5. 권한 부여<br/>(그룹 또는 정책)
    IAM->>Admin: 6. 자격 증명 제공
    Admin->>User: 7. 자격 증명 전달<br/>(보안 채널)
    User->>IAM: 8. 첫 로그인<br/>(비밀번호 변경 강제)
```

#### Access Key 관리

**Access Key 구조:**
```
Access Key ID:     AKIAIOSFODNN7EXAMPLE
Secret Access Key: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

특징:
- Access Key ID: 공개 가능 (리소스 식별용)
- Secret Access Key: 절대 공개 금지 (서명 생성용)
- 생성 시 한 번만 표시 (다시 조회 불가)
```

**❌ 절대 하지 말아야 할 것:**

```python
# ❌ 코드에 하드코딩
import boto3

s3 = boto3.client('s3',
    aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
    aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/...'
)
```

**✅ 올바른 방법:**

```python
# ✅ 환경 변수 사용
import boto3
import os

s3 = boto3.client('s3')  # 자동으로 환경 변수에서 로드

# 또는 AWS CLI 프로파일 사용
s3 = boto3.Session(profile_name='dev').client('s3')

# 또는 IAM Role 사용 (EC2, Lambda 등)
s3 = boto3.client('s3')  # 자동으로 Role에서 임시 자격 증명 획득
```

**Access Key 보안 모범 사례:**

```mermaid
graph TD
    A[Access Key 보안] --> B[1. 최소 발급]
    A --> C[2. 정기 교체<br/>90일마다]
    A --> D[3. 미사용 키 삭제]
    A --> E[4. 키 활동 모니터링]

    B --> B1[필요한 경우에만<br/>Role 사용 권장]
    C --> C1[키 순환 정책 수립]
    D --> D1[IAM Credential Report]
    E --> E1[CloudTrail 분석]
```

### 3.2 IAM 그룹 (Group)

#### 그룹의 본질

**정의:** 사용자의 집합으로, 권한 관리를 간소화

```mermaid
graph TD
    A[Developers 그룹] --> B[developer1]
    A --> C[developer2]
    A --> D[developer3]

    E[정책:<br/>EC2FullAccess] -.->|할당| A
    F[정책:<br/>S3ReadOnly] -.->|할당| A

    E -.->|상속| B
    E -.->|상속| C
    E -.->|상속| D

    F -.->|상속| B
    F -.->|상속| C
    F -.->|상속| D
```

**왜 그룹을 사용하는가?**

```
상황: 10명의 개발자에게 동일한 권한 부여

❌ 그룹 없이:
- 각 사용자에게 개별적으로 정책 10번 연결
- 권한 변경 시 10명 모두 수정
- 실수 가능성 높음
- 관리 복잡

✅ 그룹 사용:
- Developers 그룹 생성
- 그룹에 정책 연결 (1번)
- 사용자를 그룹에 추가
- 권한 변경 시 그룹 정책만 수정
- 일관성 보장
```

#### 그룹의 특징

1. **그룹은 중첩 불가**
   ```mermaid
   graph TD
       A[AllEmployees 그룹]
       B[Developers 그룹]
       C[SeniorDevelopers 그룹]

       A -.X.-> B
       B -.X.-> C

       Note[그룹 안에 그룹을 넣을 수 없음]
   ```

2. **사용자는 여러 그룹 소속 가능**
   ```mermaid
   graph TD
       A[user1] --> B[Developers 그룹]
       A --> C[Auditors 그룹]

       D[정책 A] -.-> B
       E[정책 B] -.-> C

       D -.->|상속| A
       E -.->|상속| A

       Note[user1은 정책 A와 B 모두 적용됨]
   ```

3. **그룹은 다른 AWS 서비스에서 참조 불가**
   ```
   ✅ 가능:
   - S3 버킷 정책에서 IAM 사용자 참조
   - S3 버킷 정책에서 IAM 역할 참조

   ❌ 불가능:
   - S3 버킷 정책에서 IAM 그룹 참조

   이유: 그룹은 IAM 내부에서만 사용하는 관리 도구
   ```

#### 실전 그룹 설계 예시

```mermaid
graph TD
    A[조직 구조] --> B[Administrators]
    A --> C[Developers]
    A --> D[Operations]
    A --> E[ReadOnly]
    A --> F[Billing]

    B --> B1[정책: AdministratorAccess]
    B --> B2[조건: MFA 필수]

    C --> C1[정책: EC2, S3, RDS 권한]
    C --> C2[조건: 개발 환경만]

    D --> D1[정책: EC2, CloudWatch]
    D --> D2[조건: 프로덕션 환경]

    E --> E1[정책: ViewOnlyAccess]

    F --> F1[정책: Billing, Cost Explorer]
```

**각 그룹의 역할:**

```
1. Administrators 그룹
   - 대상: IT 관리자 (2-3명)
   - 권한: 모든 AWS 서비스
   - 조건: MFA 필수
   - 사용 사례: 인프라 초기 설정, 긴급 상황

2. Developers 그룹
   - 대상: 개발팀 (10-20명)
   - 권한:
     * EC2: 개발 태그가 있는 인스턴스만
     * S3: dev-* 버킷만
     * RDS: 개발 DB 읽기/쓰기
   - 조건: 개발 환경만, 업무 시간만

3. Operations 그룹
   - 대상: 운영팀 (5-10명)
   - 권한:
     * EC2: 모든 환경 관리
     * CloudWatch: 모니터링
     * Auto Scaling: 스케일링 조정
   - 조건: 프로덕션 포함, MFA 필수

4. ReadOnly 그룹
   - 대상: 감사자, 외부 컨설턴트
   - 권한: 모든 리소스 읽기만
   - 조건: 특정 IP에서만

5. Billing 그룹
   - 대상: 재무팀 (2-3명)
   - 권한: 비용 정보, 예산
   - 조건: 리소스 변경 불가
```

### 3.3 IAM 역할 (Role)

#### 역할의 본질

**정의:** **임시** 자격 증명을 제공하는 IAM 엔터티

```mermaid
graph LR
    A[IAM User<br/>영구 자격 증명] -.vs.-> B[IAM Role<br/>임시 자격 증명]

    A --> A1[비밀번호: 영구]
    A --> A2[Access Key: 영구]
    A --> A3[특정 개인/앱]

    B --> B1[임시 자격 증명]
    B --> B2[만료 시간: 15분~12시간]
    B --> B3[누구나 assume 가능]

    style A fill:#ffe1e1
    style B fill:#e1ffe1
```

**역할 vs 사용자 상세 비교:**

| 특성 | IAM 사용자 | IAM 역할 |
|------|-----------|---------|
| **자격 증명** | 영구 (비밀번호, Access Key) | 임시 (만료되는 토큰) |
| **소유** | 특정 개인/애플리케이션 | 누구나 맡을 수 있음 |
| **비밀번호** | 있음 | 없음 |
| **Access Key** | 영구 키 | 임시 키 (STS 토큰) |
| **만료** | 삭제 전까지 영구 | 15분 ~ 12시간 |
| **로그인** | 사용자 이름 + 비밀번호 | AssumeRole API 호출 |
| **보안** | 키 노출 시 위험 | 자동 만료로 안전 |
| **사용 대상** | 사람, 장기 실행 앱 | AWS 서비스, 임시 접근 |

#### 역할의 작동 원리

```mermaid
sequenceDiagram
    participant E as Entity<br/>(사용자/서비스)
    participant STS as AWS STS<br/>(Security Token Service)
    participant Role as IAM Role
    participant Resource as AWS Resource

    E->>STS: 1. AssumeRole 요청
    Note over E,STS: "S3ReadOnlyRole을 맡고 싶어요"

    STS->>Role: 2. 신뢰 정책 확인
    Note over Role: 이 Entity가 이 역할을 맡을 수 있는가?

    alt 신뢰 정책 허용
        STS->>E: 3. 임시 자격 증명 발급<br/>(Access Key + Secret + Session Token)
        Note over E: 만료 시간: 1시간

        E->>Resource: 4. 리소스 접근<br/>(임시 자격 증명 사용)
        Resource->>Resource: 5. 권한 정책 확인
        Note over Resource: 이 역할이 이 작업을 할 수 있는가?

        alt 권한 정책 허용
            Resource->>E: 6. 접근 허용
        else 권한 정책 거부
            Resource->>E: 6. 접근 거부
        end
    else 신뢰 정책 거부
        STS->>E: 3. AssumeRole 실패
    end
```

#### 역할의 두 가지 정책

**1. 신뢰 정책 (Trust Policy)** - "누가 이 역할을 맡을 수 있는가?"

```
개념: 역할의 "출입문"
질문: "당신은 들어올 자격이 있는가?"

예시: EC2 서비스만 이 역할을 맡을 수 있음
```

**신뢰 정책 구조:**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}

해석:
- Principal: EC2 서비스가
- Action: AssumeRole (이 역할을 맡는 것)을
- Effect: Allow (허용)
```

**2. 권한 정책 (Permissions Policy)** - "이 역할이 무엇을 할 수 있는가?"

```
개념: 역할이 가진 "능력"
질문: "들어온 후 무엇을 할 수 있는가?"

예시: S3 버킷 읽기 권한
```

**권한 정책 구조:**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::my-bucket/*"
    }
  ]
}

해석:
- Action: S3 객체 읽기를
- Resource: my-bucket의 모든 객체에 대해
- Effect: Allow (허용)
```

#### 역할 사용 시나리오

**시나리오 1: EC2가 S3에 접근**

```mermaid
graph TD
    A[EC2 인스턴스<br/>웹 서버] --> B[IAM Role<br/>EC2-S3-Access-Role]
    B --> C[S3 버킷<br/>이미지 저장소]

    D[애플리케이션 코드] --> E[boto3.client 's3']
    E --> F[자동으로 임시 자격 증명 획득]
    F --> G[S3 API 호출]

    style B fill:#e1ffe1
```

**왜 역할을 사용하는가?**

❌ **역할 없이 (나쁜 방법):**
```python
# EC2 인스턴스에서 실행되는 코드
import boto3

# Access Key를 코드에 하드코딩 또는 파일에 저장
s3 = boto3.client('s3',
    aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
    aws_secret_access_key='wJalrXUtnFEMI/...'
)

문제점:
1. 키가 소스 코드나 설정 파일에 노출
2. 키가 영구적 (교체 어려움)
3. 인스턴스가 해킹되면 키 노출
4. 여러 인스턴스에 동일 키 사용 (추적 어려움)
```

✅ **역할 사용 (올바른 방법):**
```python
# EC2 인스턴스에 IAM Role 연결
# 애플리케이션 코드:
import boto3

# 그냥 클라이언트 생성
s3 = boto3.client('s3')

# boto3가 자동으로:
# 1. EC2 메타데이터 서버에서 임시 자격 증명 조회
# 2. 자격 증명 만료 전 자동 갱신
# 3. S3 API 호출

장점:
1. 키를 코드에 저장할 필요 없음
2. 자동으로 임시 자격 증명 갱신
3. 인스턴스별로 다른 역할 할당 가능
4. CloudTrail에서 어떤 역할이 무엇을 했는지 추적
```

**시나리오 2: 교차 계정 접근 (Cross-Account Access)**

```mermaid
graph LR
    A[계정 A<br/>개발 계정] -.-> B[계정 B<br/>프로덕션 계정]

    C[개발자<br/>계정 A의 IAM User] --> D[AssumeRole]
    D --> E[계정 B의 역할<br/>Prod-ReadOnly-Role]
    E --> F[계정 B의 리소스<br/>읽기 접근]

    style E fill:#e1ffe1
```

**왜 필요한가?**

```
상황:
- 회사가 AWS 계정을 여러 개 사용
  * 개발 계정 (Account A)
  * 프로덕션 계정 (Account B)
  * 보안 계정 (Account C)

- 개발자는 계정 A에만 IAM 사용자 존재
- 가끔 프로덕션 로그를 확인해야 함

옵션 1: 계정 B에도 IAM 사용자 생성
→ 관리 복잡, 비밀번호 여러 개

옵션 2: 역할 사용 (권장)
→ 계정 A 사용자가 계정 B 역할을 임시로 맡음
→ 하나의 자격 증명으로 여러 계정 접근
```

**설정 과정:**

```mermaid
sequenceDiagram
    participant DevUser as 개발자<br/>(계정 A)
    participant STS as AWS STS
    participant Role as 역할<br/>(계정 B)
    participant S3 as S3 버킷<br/>(계정 B)

    Note over Role: 신뢰 정책:<br/>계정 A 사용자 허용

    DevUser->>STS: AssumeRole<br/>(계정 B 역할 ARN)
    STS->>Role: 신뢰 정책 확인
    Role->>STS: 허용
    STS->>DevUser: 임시 자격 증명

    DevUser->>S3: S3 API 호출<br/>(임시 자격 증명 사용)
    S3->>S3: 권한 정책 확인
    S3->>DevUser: 데이터 반환
```

**계정 B의 역할 신뢰 정책:**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::111111111111:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}

설명:
- 계정 A (111111111111)의 모든 사용자가
- 이 역할을 맡을 수 있음
- 단, 계정 A의 관리자가 개별 사용자에게 AssumeRole 권한을 부여해야 함
```

**계정 A 사용자의 권한 정책:**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::222222222222:role/Prod-ReadOnly-Role"
    }
  ]
}

설명:
- 계정 B (222222222222)의
- Prod-ReadOnly-Role 역할을
- 맡을 수 있는 권한
```

**시나리오 3: 페더레이션 (외부 ID 연동)**

```mermaid
graph TD
    A[기업 Active Directory<br/>또는 Google] --> B[SAML 2.0 /<br/>OIDC]
    B --> C[AWS STS]
    C --> D[IAM Role]
    D --> E[AWS 리소스 접근]

    F[직원] --> A
    F -.->|회사 계정으로 로그인| B

    style D fill:#e1ffe1
```

**왜 사용하는가?**

```
문제:
- 회사에 직원 1000명
- 각자 AWS IAM 사용자를 만들어야 하나?
- 직원 퇴사 시 IAM 사용자 삭제 관리?

해결:
- 회사의 기존 ID 시스템 (Active Directory, Google Workspace) 사용
- AWS에 별도 사용자 생성 불필요
- 직원이 회사 계정으로 AWS 로그인
- 퇴사자는 회사 ID 비활성화하면 자동으로 AWS 접근 불가
```

**시나리오 4: AWS 서비스 간 접근**

```mermaid
graph LR
    A[Lambda 함수] -->|IAM Role| B[DynamoDB]
    A -->|IAM Role| C[S3]
    A -->|IAM Role| D[SNS]

    E[Lambda Execution Role] -.-> A

    style E fill:#e1ffe1
```

**예시: Lambda가 DynamoDB와 S3에 접근**

```
Lambda 함수:
- 사용자가 업로드한 이미지 처리
- DynamoDB에 메타데이터 저장
- S3에 썸네일 저장

Lambda Execution Role 권한:
1. DynamoDB: PutItem, GetItem
2. S3: PutObject
3. CloudWatch Logs: CreateLogGroup, CreateLogStream, PutLogEvents (로깅)
```

---

## 4. IAM 정책의 완벽한 이해

### 4.1 정책이란 무엇인가?

**정의:** 권한을 **선언적으로** 정의하는 문서

```
선언적 (Declarative):
- "어떻게"가 아니라 "무엇을"
- "S3 버킷에 파일을 업로드하려면 이렇게 저렇게 해라" (X)
- "S3 버킷에 파일을 업로드할 수 있다" (O)
```

**정책의 역할:**

```mermaid
graph TD
    A[IAM 정책] --> B[허용할 작업 정의]
    A --> C[대상 리소스 정의]
    A --> D[조건 정의]

    B --> B1["s3:GetObject<br/>ec2:StartInstances"]
    C --> C1["특정 S3 버킷<br/>특정 EC2 인스턴스"]
    D --> D1["IP 주소<br/>시간대<br/>MFA 여부"]
```

### 4.2 정책의 종류

```mermaid
graph TD
    A[IAM 정책] --> B[관리형 정책<br/>Managed Policy]
    A --> C[인라인 정책<br/>Inline Policy]

    B --> B1[AWS 관리형<br/>AWS Managed]
    B --> B2[고객 관리형<br/>Customer Managed]

    B1 --> B1A["AWS가 생성/관리<br/>예: AdministratorAccess"]
    B2 --> B2A[사용자가 생성/관리<br/>재사용 가능]

    C --> C1[특정 사용자/역할에<br/>직접 포함]
    C --> C2[1:1 관계]
```

#### 1. AWS 관리형 정책 (AWS Managed Policy)

**특징:**
- AWS가 생성하고 관리
- 일반적인 사용 사례를 위해 미리 정의
- AWS가 업데이트 (새 서비스 출시 시 자동 반영)
- 수정 불가 (읽기 전용)

**주요 AWS 관리형 정책:**

```
AdministratorAccess:
- 모든 AWS 서비스와 리소스에 대한 완전한 권한
- 사용 사례: IT 관리자
- ARN: arn:aws:iam::aws:policy/AdministratorAccess

PowerUserAccess:
- IAM 제외한 모든 서비스 접근
- 사용 사례: 개발자
- 제한: IAM 사용자/그룹/역할 관리 불가

ReadOnlyAccess:
- 모든 서비스 읽기 전용
- 사용 사례: 감사자, 모니터링

AmazonS3FullAccess:
- S3의 모든 작업
- 사용 사례: S3 관리자

AmazonS3ReadOnlyAccess:
- S3 읽기만
- 사용 사례: 분석가
```

**언제 사용하는가?**
```
✅ 좋은 경우:
- 표준적인 권한이 필요할 때
- 빠르게 시작하고 싶을 때
- AWS의 업데이트를 자동으로 받고 싶을 때

❌ 피해야 할 경우:
- 세밀한 권한 제어 필요
- 회사 고유의 보안 정책
- 최소 권한 원칙 적용 (대부분의 AWS 관리형 정책은 너무 광범위)
```

#### 2. 고객 관리형 정책 (Customer Managed Policy)

**특징:**
- 사용자가 직접 생성하고 관리
- 여러 사용자/그룹/역할에 재사용 가능
- 완전한 제어 가능
- 버전 관리 가능 (최대 5개 버전)

**언제 사용하는가?**
```
✅ 권장:
- 최소 권한 원칙 적용
- 회사 고유의 보안 요구사항
- 특정 리소스만 접근
- 조건부 권한 (IP, 시간, MFA 등)

예시: 특정 S3 버킷의 특정 폴더만 접근
```

**고객 관리형 정책 예시:**

```
정책 이름: Developer-EC2-Dev-Only

목적: 개발자가 개발 환경 EC2만 관리

내용:
- EC2 인스턴스 중 Tag "Environment=Dev"만
- 작업: 시작, 중지, 재부팅
- 제한: 삭제, 생성 불가
```

#### 3. 인라인 정책 (Inline Policy)

**특징:**
- 사용자/그룹/역할에 직접 포함
- 1:1 관계 (엔터티 삭제 시 정책도 삭제)
- 재사용 불가

**언제 사용하는가?**
```
✅ 사용:
- 엄격한 1:1 관계 유지 필요
- 정책이 특정 사용자/역할에만 적용
- 정책이 실수로 다른 곳에 사용되는 것 방지

예시:
- 특정 Lambda 함수만 특정 S3 버킷에 접근
- 이 역할이 삭제되면 권한도 함께 삭제되어야 함

❌ 대부분의 경우:
- 관리형 정책 사용 권장
- 재사용성, 중앙 관리, 감사 용이
```

### 4.3 정책 평가 로직

AWS는 여러 정책을 어떻게 평가하여 최종 결정을 내릴까?

#### 평가 순서

```mermaid
graph TD
    A[요청 시작] --> B{1. 명시적 Deny 있는가?}
    B -->|Yes| C[거부 Deny]
    B -->|No| D{2. 명시적 Allow 있는가?}
    D -->|Yes| E[허용 Allow]
    D -->|No| F[거부 Implicit Deny]

    style C fill:#ffe1e1
    style E fill:#e1ffe1
    style F fill:#ffe1e1
```

**기본 원칙:**
```
1. 기본적으로 모든 것 거부 (Implicit Deny)
2. 명시적 Deny가 최우선 (Explicit Deny)
3. 명시적 Allow가 있어야 허용 (Explicit Allow)

요약: Deny가 하나라도 있으면 무조건 거부
```

#### 시나리오로 이해하기

**시나리오 1: 단일 정책**

```
사용자: developer1
정책: S3ReadOnlyAccess

요청: S3 버킷에서 파일 읽기
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (S3ReadOnlyAccess)
→ 허용
```

**시나리오 2: 여러 정책 - 모두 Allow**

```
사용자: developer1
정책 1: S3ReadOnlyAccess (Allow s3:GetObject)
정책 2: EC2FullAccess (Allow ec2:*)

요청: S3 버킷에서 파일 읽기
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (정책 1)
→ 허용

요청: EC2 인스턴스 시작
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (정책 2)
→ 허용
```

**시나리오 3: Allow와 Deny 충돌**

```
사용자: developer1
정책 1: S3FullAccess (Allow s3:*)
정책 2: DenyProductionBuckets (Deny s3:* on prod-*)

요청: dev-bucket에서 파일 읽기
평가:
1. 명시적 Deny? 없음 (prod-* 만 Deny)
2. 명시적 Allow? 있음 (정책 1)
→ 허용

요청: prod-bucket에서 파일 읽기
평가:
1. 명시적 Deny? 있음 (정책 2)
→ 거부 (Deny가 최우선!)
```

**시나리오 4: 그룹 + 개별 정책**

```
사용자: developer1
그룹: Developers (S3ReadOnlyAccess)
사용자 직접 정책: EC2FullAccess

요청: S3 버킷에서 파일 읽기
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (그룹 정책)
→ 허용

요청: S3 버킷에 파일 쓰기
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 없음 (ReadOnly만 있음)
→ 거부 (Implicit Deny)
```

**시나리오 5: 권한 경계 (Permission Boundary)**

```mermaid
graph TD
    A[사용자 정책:<br/>AdministratorAccess] --> C[교집합]
    B[권한 경계:<br/>S3 + EC2만] --> C

    C --> D[실제 권한:<br/>S3 + EC2에 대한 모든 권한]

    E[RDS 접근 시도] -->|권한 경계에 없음| F[거부]
    G[S3 접근 시도] -->|교집합에 포함| H[허용]
```

```
사용자: junior-admin
정책: AdministratorAccess (모든 서비스)
권한 경계: S3 + EC2만 허용

요청: S3 버킷 생성
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (AdministratorAccess)
3. 권한 경계 확인? S3 포함됨
→ 허용

요청: RDS 데이터베이스 생성
평가:
1. 명시적 Deny? 없음
2. 명시적 Allow? 있음 (AdministratorAccess)
3. 권한 경계 확인? RDS 포함 안됨
→ 거부
```

### 4.4 정책 문서 구조

정책은 **JSON 형식**으로 작성되며, 여러 요소로 구성됩니다.

#### 기본 구조

```
{
  "Version": "2012-10-17",
  "Id": "PolicyId (선택)",
  "Statement": [
    {
      "Sid": "StatementId (선택)",
      "Effect": "Allow" 또는 "Deny",
      "Principal": "누가 (역할/사용자)",
      "Action": "무엇을",
      "Resource": "어디에",
      "Condition": "어떤 조건에서"
    }
  ]
}
```

#### 각 요소 상세 설명

**1. Version (필수)**
```
"Version": "2012-10-17"

- 정책 언어 버전
- 항상 "2012-10-17" 사용 (최신 버전)
- 이전 버전 "2008-10-17"은 사용 안 함 (변수 미지원)
```

**2. Statement (필수)**
```
"Statement": [
  { ... },
  { ... }
]

- 권한 규칙의 배열
- 여러 개의 규칙 포함 가능
- 각 Statement는 독립적으로 평가됨
```

**3. Sid (선택)**
```
"Sid": "AllowS3ReadAccess"

- Statement ID
- 설명 목적, 정책 평가에 영향 없음
- 같은 정책 내에서 고유해야 함
- 권장: 의미 있는 이름 사용
```

**4. Effect (필수)**
```
"Effect": "Allow" 또는 "Deny"

Allow:
- 명시된 작업 허용
- 다른 Deny가 없으면 최종 허용

Deny:
- 명시된 작업 거부
- 최우선 순위
- 어떤 Allow도 무시됨
```

**5. Principal (조건부 필수)**
```
"Principal": {
  "AWS": "arn:aws:iam::123456789012:user/developer1"
}

- 누가 이 정책을 적용받는가
- Resource-based 정책에서 필수 (S3 버킷 정책, IAM 역할 신뢰 정책)
- Identity-based 정책에서 불필요 (사용자/그룹/역할에 직접 연결)

유형:
- AWS 계정: {"AWS": "arn:aws:iam::123456789012:root"}
- IAM 사용자: {"AWS": "arn:aws:iam::123456789012:user/name"}
- IAM 역할: {"AWS": "arn:aws:iam::123456789012:role/name"}
- AWS 서비스: {"Service": "ec2.amazonaws.com"}
- 모든 사람: {"AWS": "*"} (공개)
```

**6. Action (필수)**
```
"Action": "s3:GetObject"

또는

"Action": [
  "s3:GetObject",
  "s3:PutObject"
]

- 허용/거부할 작업
- 서비스:작업 형식
- 와일드카드 가능: "s3:*" (S3의 모든 작업)

예시:
- "ec2:RunInstances" : EC2 인스턴스 시작
- "s3:*" : S3의 모든 작업
- "iam:Get*" : IAM의 모든 Get 작업
- "*" : 모든 서비스의 모든 작업
```

**7. Resource (필수)**
```
"Resource": "arn:aws:s3:::my-bucket/*"

또는

"Resource": [
  "arn:aws:s3:::my-bucket",
  "arn:aws:s3:::my-bucket/*"
]

- 대상 리소스
- ARN (Amazon Resource Name) 형식
- 와일드카드 가능

예시:
- "arn:aws:s3:::my-bucket" : 버킷 자체
- "arn:aws:s3:::my-bucket/*" : 버킷 내 모든 객체
- "arn:aws:ec2:*:*:instance/*" : 모든 리전의 모든 인스턴스
- "*" : 모든 리소스
```

**8. Condition (선택)**
```
"Condition": {
  "조건 연산자": {
    "조건 키": "조건 값"
  }
}

- 추가 제약 조건
- 매우 강력한 기능
- 다양한 컨텍스트 정보 활용
```

#### 조건 (Condition) 상세

조건은 정책의 가장 강력한 기능 중 하나입니다.

**조건 연산자:**

| 연산자 | 설명 | 예시 |
|--------|------|------|
| **StringEquals** | 문자열 일치 | `"StringEquals": {"aws:username": "developer1"}` |
| **StringLike** | 와일드카드 매칭 | `"StringLike": {"s3:prefix": ["photos/*"]}` |
| **NumericLessThan** | 숫자 비교 | `"NumericLessThan": {"s3:max-keys": "10"}` |
| **DateGreaterThan** | 날짜 비교 | `"DateGreaterThan": {"aws:CurrentTime": "2024-01-01T00:00:00Z"}` |
| **Bool** | 불린 값 | `"Bool": {"aws:SecureTransport": "true"}` |
| **IpAddress** | IP 범위 | `"IpAddress": {"aws:SourceIp": "203.0.113.0/24"}` |
| **ArnLike** | ARN 패턴 | `"ArnLike": {"aws:SourceArn": "arn:aws:s3:::my-bucket"}` |

**주요 조건 키:**

```
aws:CurrentTime : 현재 시간
aws:EpochTime : Unix 타임스탬프
aws:SecureTransport : HTTPS 사용 여부
aws:SourceIp : 요청 출발지 IP
aws:UserAgent : 사용자 에이전트
aws:username : IAM 사용자 이름
aws:MultiFactorAuthPresent : MFA 사용 여부
aws:MultiFactorAuthAge : MFA 인증 경과 시간
```

**실전 조건 예시:**

**예시 1: 특정 IP에서만 접근**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:*",
      "Resource": "*",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "203.0.113.0/24"
        }
      }
    }
  ]
}

설명:
- S3의 모든 작업 허용
- 단, 203.0.113.0/24 IP 범위에서만
- 회사 네트워크에서만 접근 허용
```

**예시 2: 업무 시간에만 접근**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "ec2:*",
      "Resource": "*",
      "Condition": {
        "DateGreaterThan": {
          "aws:CurrentTime": "2024-01-01T09:00:00Z"
        },
        "DateLessThan": {
          "aws:CurrentTime": "2024-01-01T18:00:00Z"
        }
      }
    }
  ]
}

설명:
- EC2의 모든 작업 허용
- 09:00 ~ 18:00 UTC 사이에만
- 업무 시간 외 접근 차단
```

**예시 3: MFA 필수**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "ec2:TerminateInstances",
      "Resource": "*",
      "Condition": {
        "Bool": {
          "aws:MultiFactorAuthPresent": "true"
        }
      }
    }
  ]
}

설명:
- EC2 인스턴스 종료 허용
- MFA 인증한 경우에만
- 중요한 작업에 2단계 인증 강제
```

**예시 4: 특정 태그가 있는 리소스만**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "ec2:StopInstances",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "ec2:ResourceTag/Environment": "Dev"
        }
      }
    }
  ]
}

설명:
- EC2 인스턴스 중지 허용
- Tag "Environment=Dev"인 인스턴스만
- 프로덕션 환경 보호
```

**예시 5: HTTPS만 허용**
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": "arn:aws:s3:::my-bucket/*",
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}

설명:
- S3의 모든 작업 거부
- HTTP 사용 시 (HTTPS가 아닐 때)
- 암호화되지 않은 통신 차단
```

### 4.5 변수와 태그 기반 제어

정책에서 **변수**를 사용하여 동적인 권한 제어가 가능합니다.

#### 정책 변수

**형식:** `${aws:변수명}`

**주요 변수:**
```
${aws:username} : IAM 사용자 이름
${aws:userid} : 고유 사용자 ID
${aws:SourceIp} : 출발지 IP
${aws:CurrentTime} : 현재 시간
${s3:prefix} : S3 접두사 (폴더)
```

**예시: 사용자별 폴더 접근**

```
시나리오:
- S3 버킷: user-files
- 구조:
  * user-files/alice/
  * user-files/bob/
  * user-files/charlie/

목표: 각 사용자가 자신의 폴더만 접근

정책:
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:*",
      "Resource": "arn:aws:s3:::user-files/${aws:username}/*"
    }
  ]
}

작동:
- 사용자 alice 로그인
  → Resource: arn:aws:s3:::user-files/alice/*
  → alice 폴더만 접근 가능

- 사용자 bob 로그인
  → Resource: arn:aws:s3:::user-files/bob/*
  → bob 폴더만 접근 가능
```

**장점:**
- 하나의 정책으로 모든 사용자 관리
- 사용자 추가 시 별도 정책 불필요
- 자동으로 개인화됨

---

## 5. AWS 권한 종류 상세

AWS에는 여러 종류의 권한 메커니즘이 있습니다.

```mermaid
graph TD
    A[AWS 권한 체계] --> B[Identity-based<br/>정책]
    A --> C[Resource-based<br/>정책]
    A --> D[Permission<br/>Boundaries]
    A --> E[Session<br/>Policies]
    A --> F[ACL]
    A --> G[Organizations<br/>SCP]
```

### 5.1 Identity-based 정책

**정의:** **누가**에게 붙는 정책 (사용자/그룹/역할)

```mermaid
graph LR
    A[IAM User] -.정책 연결.-> B[Identity-based<br/>정책]
    C[IAM Group] -.정책 연결.-> B
    D[IAM Role] -.정책 연결.-> B

    B --> E["무엇을 할 수 있는가<br/>(Action + Resource)"]
```

**특징:**
- 사용자/그룹/역할에 직접 연결
- "이 사용자가 무엇을 할 수 있는가" 정의
- Principal 필드 없음 (누가인지는 명확)

**예시:**
```
사용자: developer1

정책 1 (관리형):
- AdministratorAccess

정책 2 (고객 관리형):
- Developer-S3-Access

정책 3 (인라인):
- Developer1-Special-Access

평가: 위 3개 정책의 합집합 (단, Deny가 있으면 제외)
```

### 5.2 Resource-based 정책

**정의:** **무엇에** 붙는 정책 (리소스)

```mermaid
graph LR
    A[S3 Bucket] -.정책 연결.-> B[Bucket<br/>Policy]
    C[Lambda<br/>Function] -.정책 연결.-> D[Resource<br/>Policy]
    E[KMS Key] -.정책 연결.-> F[Key<br/>Policy]

    B --> G["누가 이 버킷에 접근할 수 있는가<br/>(Principal + Action)"]
```

**특징:**
- 리소스 자체에 붙는 정책
- "누가 이 리소스에 접근할 수 있는가" 정의
- Principal 필드 필수

**지원하는 서비스:**
```
- S3: 버킷 정책
- Lambda: 함수 정책
- SNS: 토픽 정책
- SQS: 큐 정책
- KMS: 키 정책
- Secrets Manager: 시크릿 정책
- API Gateway: 리소스 정책
```

**예시: S3 버킷 정책**

```
시나리오:
- S3 버킷: public-images
- 목표: 모든 사람이 이미지 읽기 가능 (공개 버킷)

정책:
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicRead",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::public-images/*"
    }
  ]
}

설명:
- Principal: "*" (모든 사람)
- Action: s3:GetObject (읽기만)
- Resource: public-images 버킷의 모든 객체
```

**Identity-based vs Resource-based 비교:**

```mermaid
graph TD
    subgraph "Identity-based"
        A[IAM User] -->|정책| B[S3에 접근하고 싶음]
        B --> C{권한 있는가?}
        C -->|Yes| D[허용]
        C -->|No| E[거부]
    end

    subgraph "Resource-based"
        F[S3 Bucket] -->|정책| G[누가 나에게 접근할 수 있는가?]
        G --> H{이 사용자 허용?}
        H -->|Yes| I[허용]
        H -->|No| J[거부]
    end
```

**교차 계정 접근 시:**

```
상황: 계정 A의 사용자가 계정 B의 S3 버킷에 접근

방법 1: IAM Role (Identity-based)
- 계정 B에 역할 생성
- 계정 A 사용자가 역할 assume
- 복잡하지만 임시 자격 증명 사용

방법 2: S3 Bucket Policy (Resource-based)
- 계정 B의 S3 버킷 정책에 계정 A 사용자 추가
- 간단하지만 영구적 권한
- 사용자의 자격 증명 그대로 사용
```

### 5.3 Permission Boundaries (권한 경계)

**정의:** IAM 사용자/역할이 가질 수 있는 **최대 권한 한계**

```mermaid
graph TD
    A[사용자 정책<br/>AdministratorAccess] --> C{교집합}
    B[Permission Boundary<br/>S3 + DynamoDB만] --> C

    C --> D[실제 권한<br/>S3 + DynamoDB에 대한 모든 권한]

    E[EC2 작업 시도] -->|Boundary 밖| F[거부]
    G[S3 작업 시도] -->|교집합 안| H[허용]

    style D fill:#e1ffe1
    style F fill:#ffe1e1
```

**왜 필요한가?**

```
문제:
- 팀 리더에게 팀원 IAM 사용자 관리 권한 위임
- 하지만 팀 리더가 자신에게 AdministratorAccess 부여할 수 있음
- 권한 상승 (Privilege Escalation) 위험

해결:
- 팀 리더에게 IAM 권한 부여
- Permission Boundary 설정: S3, EC2, DynamoDB만
- 팀 리더가 사용자 생성해도 Boundary 안에서만 가능
```

**설정 예시:**

```
팀 리더: team-lead

Identity-based 정책:
- IAM 사용자 생성/수정 권한
- S3, EC2, DynamoDB 모든 권한

Permission Boundary:
- S3, EC2, DynamoDB만 허용

결과:
1. 팀 리더 본인: S3, EC2, DynamoDB 모든 작업 가능
2. 팀원 생성 시: S3, EC2, DynamoDB 권한만 부여 가능
3. RDS 권한 부여 시도: 거부 (Boundary 밖)
```

**평가 로직:**

```
최종 권한 = Identity-based 정책 AND Permission Boundary

예:
Identity: {S3, EC2, RDS, Lambda}
Boundary: {S3, EC2, DynamoDB}
최종: {S3, EC2} (교집합)
```

### 5.4 Session Policies

**정의:** **임시 세션**에만 적용되는 추가 제한

```mermaid
sequenceDiagram
    participant U as 사용자
    participant STS as AWS STS
    participant S3 as S3

    U->>STS: AssumeRole<br/>+ Session Policy
    Note over STS: 역할 권한 AND Session Policy
    STS->>U: 임시 자격 증명
    U->>S3: S3 접근
    Note over S3: Session Policy 범위 내에서만 허용
```

**사용 사례:**

```
상황:
- IAM 역할: DataScientist
- 권한: 모든 S3 버킷 읽기

문제:
- 외부 컨설턴트에게 임시 접근 권한 부여
- 하지만 특정 버킷만 접근 허용하고 싶음

해결:
- AssumeRole 시 Session Policy 전달
- Session Policy: public-datasets 버킷만 허용

결과:
- 역할 권한: 모든 S3 버킷 읽기
- Session Policy: public-datasets만
- 최종: public-datasets 버킷만 읽기 가능
```

### 5.5 ACL (Access Control List)

**정의:** **레거시** 권한 메커니즘 (IAM 이전)

```
ACL 특징:
- IAM보다 오래됨
- 제한적 기능 (읽기, 쓰기 수준)
- AWS 계정 또는 그룹 단위
- S3, VPC에서 사용

권장:
- 새로운 시스템: IAM 정책 사용
- 기존 시스템: 호환성 유지용
```

**S3 ACL 예시:**

```
S3 객체 ACL:
- 소유자: 모든 권한
- AWS 계정 123456789012: 읽기
- 모든 사람 (public): 읽기

vs

S3 버킷 정책 (권장):
- 세밀한 제어
- 조건부 권한
- CloudTrail 로깅
```

**Network ACL (NACL):**

```
VPC의 서브넷 수준 방화벽:
- Stateless (상태 비저장)
- 명시적 Allow + Deny
- 규칙 번호 순서대로 평가

예시:
100: Allow HTTP from 0.0.0.0/0
200: Allow HTTPS from 0.0.0.0/0
300: Deny All from 203.0.113.0/24
*  : Deny All
```

---

## 6. ARN - Amazon Resource Name

### 6.1 ARN이란 무엇인가?

**ARN (Amazon Resource Name):**
- AWS의 **모든 리소스를 고유하게 식별**하는 이름
- IAM 정책에서 리소스를 지정할 때 사용
- AWS API 호출 시 리소스 식별

```mermaid
graph LR
    A[ARN] --> B[서비스 식별]
    A --> C[리전 식별]
    A --> D[계정 식별]
    A --> E[리소스 식별]
```

### 6.2 ARN 구조

```
arn:partition:service:region:account-id:resource-type/resource-id
│   │         │       │      │          │
│   │         │       │      │          └─ 리소스 타입과 ID
│   │         │       │      └─ AWS 계정 ID (12자리)
│   │         │       └─ 리전 (예: ap-northeast-2)
│   │         └─ AWS 서비스 (예: s3, ec2, iam)
│   └─ 파티션 (거의 항상 "aws")
└─ ARN임을 나타냄
```

**각 부분 설명:**

| 부분 | 설명 | 예시 |
|------|------|------|
| **arn** | ARN 접두사 (고정) | arn |
| **partition** | AWS 파티션 | aws (대부분), aws-cn (중국), aws-us-gov (미국 정부) |
| **service** | AWS 서비스 | s3, ec2, iam, lambda, dynamodb |
| **region** | 리전 코드 | ap-northeast-2 (서울), us-east-1 (버지니아), * (모든 리전) |
| **account-id** | 12자리 계정 ID | 123456789012, * (모든 계정) |
| **resource** | 리소스 타입/ID | bucket/my-bucket, instance/i-1234567890abcdef0 |

### 6.3 서비스별 ARN 형식

#### S3 ARN

```
버킷:
arn:aws:s3:::my-bucket

버킷 내 객체:
arn:aws:s3:::my-bucket/path/to/file.txt

모든 객체:
arn:aws:s3:::my-bucket/*

특징:
- 리전 없음 (S3는 글로벌 네임스페이스)
- 계정 ID 없음 (버킷 이름이 전 세계적으로 고유)
```

#### EC2 ARN

```
인스턴스:
arn:aws:ec2:ap-northeast-2:123456789012:instance/i-1234567890abcdef0

보안 그룹:
arn:aws:ec2:ap-northeast-2:123456789012:security-group/sg-0abcdef1234567890

VPC:
arn:aws:ec2:ap-northeast-2:123456789012:vpc/vpc-0abcdef1234567890

모든 인스턴스:
arn:aws:ec2:*:*:instance/*

특징:
- 리전 필수 (EC2는 리전 서비스)
- 계정 ID 필수
```

#### IAM ARN

```
사용자:
arn:aws:iam::123456789012:user/developer1

그룹:
arn:aws:iam::123456789012:group/Developers

역할:
arn:aws:iam::123456789012:role/EC2-S3-Access-Role

정책:
arn:aws:iam::123456789012:policy/MyCustomPolicy

AWS 관리형 정책:
arn:aws:iam::aws:policy/AdministratorAccess

특징:
- 리전 없음 (IAM은 글로벌)
- 계정 ID 필수 (AWS 관리형 정책은 "aws")
```

#### Lambda ARN

```
함수:
arn:aws:lambda:us-east-1:123456789012:function:my-function

특정 버전:
arn:aws:lambda:us-east-1:123456789012:function:my-function:2

별칭:
arn:aws:lambda:us-east-1:123456789012:function:my-function:prod
```

#### DynamoDB ARN

```
테이블:
arn:aws:dynamodb:ap-northeast-2:123456789012:table/MyTable

스트림:
arn:aws:dynamodb:ap-northeast-2:123456789012:table/MyTable/stream/2024-12-11T10:00:00.000
```

### 6.4 ARN 와일드카드

정책에서 **여러 리소스를 한 번에 지정**할 때 와일드카드를 사용합니다.

```
* : 0개 이상의 문자
? : 정확히 1개의 문자
```

**예시:**

```
1. S3 버킷의 모든 객체:
arn:aws:s3:::my-bucket/*

2. 모든 S3 버킷:
arn:aws:s3:::*

3. 특정 접두사로 시작하는 S3 객체:
arn:aws:s3:::my-bucket/logs/*

4. 모든 리전의 모든 EC2 인스턴스:
arn:aws:ec2:*:*:instance/*

5. 특정 리전의 모든 EC2 인스턴스:
arn:aws:ec2:ap-northeast-2:*:instance/*

6. dev-로 시작하는 모든 IAM 사용자:
arn:aws:iam::123456789012:user/dev-*
```

### 6.5 ARN 활용 예시

**예시 1: 특정 S3 버킷만 접근**

```
정책:
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": "arn:aws:s3:::my-app-bucket/*"
    },
    {
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::my-app-bucket"
    }
  ]
}

설명:
- 버킷 내 객체에 대한 작업 (GetObject, PutObject)
- 버킷 자체에 대한 작업 (ListBucket)
- ARN을 명확히 구분
```

**예시 2: 여러 리소스 지정**

```
정책:
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": [
        "arn:aws:s3:::bucket1/*",
        "arn:aws:s3:::bucket2/*",
        "arn:aws:s3:::bucket3/*"
      ]
    }
  ]
}
```

**예시 3: 계정 간 접근**

```
정책 (계정 B의 S3 버킷 정책):
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::111111111111:user/alice"
      },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::account-b-bucket/*"
    }
  ]
}

설명:
- 계정 A (111111111111)의 사용자 alice가
- 계정 B의 버킷에 접근 가능
- ARN으로 정확한 사용자 지정
```

---

## 7. SCP와 조직 권한 관리

### 7.1 AWS Organizations

**AWS Organizations:**
- 여러 AWS 계정을 **중앙에서 관리**하는 서비스
- 계정 그룹화 (OU - Organizational Unit)
- 통합 결제
- **SCP (Service Control Policy)**로 권한 제어

```mermaid
graph TD
    A[Root<br/>조직 루트] --> B[OU: Production<br/>조직 단위]
    A --> C[OU: Development]
    A --> D[OU: Sandbox]

    B --> B1[계정: prod-web]
    B --> B2[계정: prod-db]

    C --> C1[계정: dev-team1]
    C --> C2[계정: dev-team2]

    D --> D1[계정: sandbox]

    E[SCP: DenyAllButApprovedRegions] -.-> A
    F[SCP: DenyExpensiveServices] -.-> C
    G[SCP: FullAccess] -.-> B
```

### 7.2 SCP (Service Control Policy)

**SCP란?**
- **조직 내 계정**에 대한 **최대 권한 한계**
- 계정 전체에 영향 (루트 사용자 포함!)
- 권한을 **부여하지 않음**, **제한만** 함

```mermaid
graph TD
    A[계정의 IAM 정책] --> C{교집합}
    B[조직의 SCP] --> C

    C --> D[실제 사용 가능한 권한]

    E[IAM: EC2, S3, RDS 허용] --> C
    F[SCP: EC2, S3만 허용] --> C
    C --> G[최종: EC2, S3만 사용 가능]

    style G fill:#e1ffe1
```

**중요한 특징:**

```
1. SCP는 권한을 부여하지 않음
   - IAM 정책이 여전히 필요
   - SCP는 IAM 정책의 상한선만 설정

2. 루트 사용자에게도 적용
   - IAM 정책으로 제한할 수 없는 루트 사용자도 SCP로 제한 가능

3. 서비스별, 리전별 제한 가능
   - 특정 서비스 사용 금지
   - 특정 리전만 사용 허용
```

### 7.3 SCP 전략

#### 1. 거부 목록 (Deny List) 전략

**기본적으로 모든 것 허용**, 특정 것만 거부

```
기본 SCP: FullAWSAccess (모든 서비스 허용)

+ 추가 SCP: 특정 서비스 거부
```

**예시: 비용이 많이 드는 서비스 차단**

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Deny",
      "Action": [
        "ec2:RunInstances"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "ec2:InstanceType": [
            "p3.16xlarge",
            "p3dn.24xlarge",
            "p4d.24xlarge"
          ]
        }
      }
    }
  ]
}

설명:
- GPU 인스턴스 (매우 비쌈) 생성 금지
- 다른 모든 인스턴스는 허용
```

#### 2. 허용 목록 (Allow List) 전략

**기본적으로 모든 것 거부**, 특정 것만 허용

```
기본: FullAWSAccess 제거

+ SCP: 특정 서비스만 명시적 허용
```

**예시: 승인된 서비스만 사용**

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ec2:*",
        "s3:*",
        "rds:*",
        "cloudwatch:*"
      ],
      "Resource": "*"
    }
  ]
}

설명:
- EC2, S3, RDS, CloudWatch만 사용 가능
- Lambda, DynamoDB 등 다른 서비스는 사용 불가
- 보안은 강화되지만 유연성 감소
```

### 7.4 SCP 실전 예시

**예시 1: 특정 리전만 허용**

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyAllOutsideApprovedRegions",
      "Effect": "Deny",
      "Action": "*",
      "Resource": "*",
      "Condition": {
        "StringNotEquals": {
          "aws:RequestedRegion": [
            "ap-northeast-2",
            "us-east-1"
          ]
        }
      }
    }
  ]
}

설명:
- 서울(ap-northeast-2)과 버지니아(us-east-1)만 사용 가능
- 다른 리전에서 리소스 생성 시도 시 거부
- 데이터 주권, 컴플라이언스 준수
```

**예시 2: 루트 사용자 보호**

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RequireMFAForRoot",
      "Effect": "Deny",
      "Action": "*",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:PrincipalType": "Root"
        },
        "BoolIfExists": {
          "aws:MultiFactorAuthPresent": "false"
        }
      }
    }
  ]
}

설명:
- 루트 사용자가 MFA 없이 작업 시도 시 거부
- 루트 계정 보안 강화
```

**예시 3: 개발 환경 비용 제한**

```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyExpensiveInstanceTypes",
      "Effect": "Deny",
      "Action": "ec2:RunInstances",
      "Resource": "arn:aws:ec2:*:*:instance/*",
      "Condition": {
        "StringNotLike": {
          "ec2:InstanceType": [
            "t2.*",
            "t3.*",
            "t3a.*"
          ]
        }
      }
    }
  ]
}

설명:
- 개발 계정에서 t2, t3 시리즈만 사용 가능
- 고성능/고비용 인스턴스 생성 차단
```

### 7.5 SCP vs IAM 정책

```mermaid
graph TD
    A[SCP] --> A1[조직/OU/계정 수준]
    A --> A2[권한 제한만 가능]
    A --> A3[루트 사용자에게도 적용]
    A --> A4[상한선 설정]

    B[IAM 정책] --> B1[사용자/그룹/역할 수준]
    B --> B2[권한 부여 가능]
    B --> B3[루트 사용자 제한 불가]
    B --> B4[실제 권한 부여]
```

| 특성 | SCP | IAM 정책 |
|------|-----|---------|
| **적용 대상** | 계정 전체 | 특정 사용자/역할 |
| **권한 부여** | 불가 (제한만) | 가능 |
| **루트 사용자** | 적용됨 | 적용 안됨 |
| **목적** | 조직 전체 가드레일 | 세밀한 권한 제어 |
| **우선순위** | 상한선 | 하한선 |

**함께 작동하는 방식:**

```
예시:

SCP (계정 수준):
- EC2, S3, RDS만 허용

IAM 정책 (사용자 수준):
- EC2 모든 권한
- S3 읽기만
- Lambda 모든 권한

최종 권한:
- EC2 모든 권한 (O) - SCP와 IAM 모두 허용
- S3 읽기 (O) - SCP와 IAM 모두 허용
- Lambda (X) - SCP에서 차단

결론: SCP AND IAM = 실제 권한
```

---

## 8. 최소 권한 원칙과 보안

### 8.1 최소 권한 원칙 실천

#### 단계별 접근

```mermaid
graph TD
    A[1. 현재 작업 파악] --> B[2. 필요한 작업만 나열]
    B --> C[3. 필요한 리소스만 지정]
    C --> D[4. 조건 추가]
    D --> E[5. 정기 검토]
    E --> F[6. 불필요한 권한 제거]
```

**1단계: 현재 작업 파악**

```
질문:
- 이 사용자/역할이 실제로 무엇을 하는가?
- 어떤 AWS 서비스를 사용하는가?
- 어떤 리소스에 접근하는가?

도구:
- CloudTrail: 실제 API 호출 기록 분석
- IAM Access Analyzer: 사용되지 않는 권한 식별
- IAM Credential Report: 사용자 활동 확인
```

**2단계: 필요한 작업만 나열**

```
잘못된 예:
"Action": "*"  (모든 작업)

개선:
"Action": "s3:*"  (S3의 모든 작업)

더 좋은 예:
"Action": [
  "s3:GetObject",
  "s3:PutObject"
]  (읽기와 쓰기만)
```

**3단계: 필요한 리소스만 지정**

```
잘못된 예:
"Resource": "*"  (모든 리소스)

개선:
"Resource": "arn:aws:s3:::*"  (모든 S3 버킷)

더 좋은 예:
"Resource": "arn:aws:s3:::my-app-bucket/*"  (특정 버킷만)
```

**4단계: 조건 추가**

```
기본 권한:
{
  "Effect": "Allow",
  "Action": "ec2:TerminateInstances",
  "Resource": "*"
}

조건 추가:
{
  "Effect": "Allow",
  "Action": "ec2:TerminateInstances",
  "Resource": "*",
  "Condition": {
    "StringEquals": {
      "ec2:ResourceTag/Environment": "Dev"
    },
    "Bool": {
      "aws:MultiFactorAuthPresent": "true"
    }
  }
}

개선 사항:
- 개발 환경만
- MFA 필수
```

### 8.2 IAM 보안 모범 사례

#### 1. 루트 사용자 관리

```
✅ 해야 할 것:
1. MFA 즉시 활성화
2. 강력한 비밀번호 설정
3. Access Key 생성 금지
4. 일상 작업에 사용 금지

✅ 루트 사용자 사용이 필요한 경우만:
- 계정 설정 변경
- 결제 정보 수정
- AWS Support 플랜 변경
- 계정 폐쇄

✅ 사용 후:
- 즉시 로그아웃
- 활동 CloudTrail 확인
```

#### 2. IAM 사용자 관리

```
✅ 개별 사용자 생성:
- 공유 계정 금지
- 각 사람마다 고유 사용자

✅ 그룹 활용:
- 사용자에게 직접 정책 연결 금지
- 그룹에 정책 연결 후 사용자 추가

✅ 비밀번호 정책:
- 최소 길이: 14자 이상
- 복잡도 요구: 대문자, 소문자, 숫자, 특수문자
- 만료 기간: 90일
- 재사용 금지: 최근 24개

✅ 정기 검토:
- 분기마다 사용자 목록 검토
- 퇴사자 계정 즉시 삭제
- 장기 미사용 계정 비활성화
```

#### 3. 역할 활용

```
✅ EC2/Lambda에는 역할 사용:
- Access Key 하드코딩 금지
- 자동 자격 증명 갱신

✅ 교차 계정 접근:
- 역할 기반 위임
- 임시 자격 증명

✅ 외부 ID 연동:
- SAML/OIDC 페더레이션
- AWS SSO (IAM Identity Center)
```

#### 4. 정책 관리

```
✅ 고객 관리형 정책:
- 회사 표준 정책 정의
- 버전 관리
- 재사용

✅ 정책 시뮬레이터:
- 배포 전 테스트
- 의도하지 않은 권한 확인

✅ 정기 감사:
- IAM Access Analyzer
- 과도한 권한 식별
- 사용되지 않는 권한 제거
```

#### 5. 모니터링과 알림

```
✅ CloudTrail:
- 모든 계정에서 활성화
- S3 로그 장기 보관
- 무결성 검증

✅ CloudWatch 알림:
- 루트 사용자 로그인
- IAM 정책 변경
- MFA 비활성화
- Access Key 생성

✅ GuardDuty:
- 비정상 활동 탐지
- 자격 증명 유출 감지
```

### 8.3 보안 점검 체크리스트

```
[ ] 루트 사용자
    [ ] MFA 활성화
    [ ] Access Key 없음
    [ ] 최근 90일 미사용

[ ] IAM 사용자
    [ ] 모든 사용자 MFA 활성화
    [ ] 비밀번호 정책 설정
    [ ] 불필요한 사용자 제거
    [ ] Access Key 순환 (90일)

[ ] IAM 역할
    [ ] EC2/Lambda에 역할 사용
    [ ] 최소 권한 원칙 적용
    [ ] 신뢰 정책 검토

[ ] IAM 정책
    [ ] 와일드카드(*) 최소화
    [ ] 조건 활용
    [ ] 정기 검토 (분기)

[ ] 모니터링
    [ ] CloudTrail 활성화
    [ ] 알림 설정
    [ ] 로그 정기 검토

[ ] 조직 (Organizations)
    [ ] SCP 설정
    [ ] 리전 제한
    [ ] 서비스 제한
```

---

## 요약

### IAM 핵심 개념

**1. 인증 vs 인가**
- 인증: 당신은 누구인가?
- 인가: 무엇을 할 수 있는가?

**2. IAM 구성 요소**
```
사용자 (User): 영구 자격 증명
그룹 (Group): 사용자 묶음
역할 (Role): 임시 자격 증명
정책 (Policy): 권한 정의
```

**3. 정책 평가**
```
1. 기본: 모든 것 거부 (Implicit Deny)
2. 명시적 Deny 확인 (최우선)
3. 명시적 Allow 확인
→ Deny > Allow > 기본 거부
```

**4. 권한 종류**
```
Identity-based: 사용자/역할에 붙음
Resource-based: 리소스에 붙음
Permission Boundaries: 최대 권한 한계
Session Policies: 임시 세션 제한
SCP: 조직/계정 제한
```

**5. ARN**
```
arn:partition:service:region:account-id:resource

모든 AWS 리소스의 고유 식별자
정책에서 리소스 지정 시 사용
```

**6. 최소 권한 원칙**
```
필요한 최소한의 권한만 부여
정기적 검토 및 제거
조건 활용으로 세밀한 제어
```

### 학습 체크리스트

- [ ] 인증과 인가의 차이를 설명할 수 있다
- [ ] IAM 사용자, 그룹, 역할의 차이를 안다
- [ ] 정책 평가 로직을 이해했다
- [ ] ARN 구조를 파악하고 작성할 수 있다
- [ ] SCP와 IAM 정책의 차이를 안다
- [ ] 최소 권한 원칙을 실천할 수 있다
- [ ] 보안 모범 사례를 적용할 수 있다

---

**이전**: [Chapter 2: AWS 사용 시작하기](./Chapter02_AWS사용시작하기_상세.md)
**다음**: [Chapter 4: VPC](./Chapter04_VPC_상세.md)
